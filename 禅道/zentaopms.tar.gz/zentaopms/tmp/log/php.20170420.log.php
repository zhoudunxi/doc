<?php
 die();
?>

10:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

10:19:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

15:21:03 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

16:25:37 Undefined index: branch in module/project/model.php on line 837 when visiting /www/index.php?m=project&f=create

17:25:05 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/model.php on line 52 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/model.php on line 52 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/model.php on line 53 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/model.php on line 53 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Invalid argument supplied for foreach() in module/project/model.php on line 55 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:25:05 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:27:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:27:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

17:41:19 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Undefined property: router::$user in module/project/model.php on line 52 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Trying to get property of non-object in module/project/model.php on line 52 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Undefined property: router::$user in module/project/model.php on line 53 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Trying to get property of non-object in module/project/model.php on line 53 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:19 Invalid argument supplied for foreach() in module/project/model.php on line 55 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

17:41:20 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

18:32:57 Undefined offset: 1 in module/common/model.php on line 727 when visiting /www/index.php?m=bug&f=browse&productID=0&branch=&browseType=unclosed¶m=0&orderBy=&recTotal=169&recPerPage=20&pageID=1

18:33:09 ERROR: SQLSTATE[42S22]: Column not found: 1054 Unknown column '169' in 'order clause'The sql is: SELECT * FROM `zt_bug` wHeRe project IN ('16','14','12','11','10','8','7','6','4','3','2','1','0') AND product  = '25' AND status  != 'closed' AND deleted  = '0' oRdEr bY `169`,`id` asc   limit 0, 20  in lib/dao/dao.class.php on line 1074, last called by lib/dao/dao.class.php on line 526 through function sqlError.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bug&f=browse

18:33:23 ERROR: SQLSTATE[42S22]: Column not found: 1054 Unknown column '169' in 'order clause'The sql is: SELECT * FROM `zt_bug` wHeRe project IN ('16','14','12','11','10','8','7','6','4','3','2','1','0') AND product  = '25' AND status  != 'closed' AND deleted  = '0' oRdEr bY `169`,`id` asc   limit 0, 20  in lib/dao/dao.class.php on line 1074, last called by lib/dao/dao.class.php on line 526 through function sqlError.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bug&f=browse&productID=0&branch=&browseType=unclosed&param=0&orderBy=&recTotal=169&recPerPage=20&pageID=1

18:35:03 ERROR: SQLSTATE[42S22]: Column not found: 1054 Unknown column '169' in 'order clause'The sql is: SELECT * FROM `zt_bug` wHeRe project IN ('16','14','12','11','10','8','7','6','4','3','2','1','0') AND product  = '25' AND status  != 'closed' AND deleted  = '0' oRdEr bY `169`,`id` asc   limit 0, 20  in lib/dao/dao.class.php on line 1074, last called by lib/dao/dao.class.php on line 526 through function sqlError.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bug&f=browse&productID=0&branch=&browseType=unclosed&param=0&orderBy=&recTotal=169&recPerPage=20&pageID=1

18:35:24 ERROR: SQLSTATE[42S22]: Column not found: 1054 Unknown column '169' in 'order clause'The sql is: SELECT %s FROM %s wHeRe `openedby` = 'sunwei'  AND product  = '25' AND project IN ('16','14','12','11','10','8','7','6','4','3','2','1','0') AND deleted  = '0' oRdEr bY `169`,`id` asc   limit 0, 20  in lib/dao/dao.class.php on line 1074, last called by lib/dao/dao.class.php on line 526 through function sqlError.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bug&f=browse&productid=25&branch=0&browseType=openedByMe&param=0

18:35:58 ERROR: SQLSTATE[42S22]: Column not found: 1054 Unknown column '169' in 'order clause'The sql is: SELECT %s FROM %s wHeRe `openedby` = 'sunwei'  AND product  = '25' AND project IN ('16','14','12','11','10','8','7','6','4','3','2','1','0') AND deleted  = '0' oRdEr bY `169`,`id` asc   limit 0, 20  in lib/dao/dao.class.php on line 1074, last called by lib/dao/dao.class.php on line 526 through function sqlError.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bug&f=browse&productid=25&branch=0&browseType=openedByMe&param=0

18:36:18 ERROR: SQLSTATE[42S22]: Column not found: 1054 Unknown column '169' in 'order clause'The sql is: SELECT * FROM `zt_bug` wHeRe project IN ('16','14','12','11','10','8','7','6','4','3','2','1','0') AND product  = '25' AND status  != 'closed' AND deleted  = '0' oRdEr bY `169`,`id` asc   limit 0, 20  in lib/dao/dao.class.php on line 1074, last called by lib/dao/dao.class.php on line 526 through function sqlError.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bug&f=browse

18:37:06 ERROR: SQLSTATE[42S22]: Column not found: 1054 Unknown column '169' in 'order clause'The sql is: SELECT * FROM `zt_bug` wHeRe project IN ('16','14','12','11','10','8','7','6','4','3','2','1','0') AND product  = '25' AND status  != 'closed' AND deleted  = '0' oRdEr bY `169`,`id` asc   limit 0, 20  in lib/dao/dao.class.php on line 1074, last called by lib/dao/dao.class.php on line 526 through function sqlError.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bug&f=browse

18:37:12 ERROR: SQLSTATE[42S22]: Column not found: 1054 Unknown column '169' in 'order clause'The sql is: SELECT * FROM `zt_bug` wHeRe project IN ('16','14','12','11','10','8','7','6','4','3','2','1','0') AND product  = '25' AND status  != 'closed' AND deleted  = '0' oRdEr bY `169`,`id` asc   limit 0, 20  in lib/dao/dao.class.php on line 1074, last called by lib/dao/dao.class.php on line 526 through function sqlError.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bug&f=browse

18:38:13 ERROR: SQLSTATE[42S22]: Column not found: 1054 Unknown column '169' in 'order clause'The sql is: SELECT * FROM `zt_bug` wHeRe project IN ('16','14','12','11','10','8','7','6','4','3','2','1','0') AND product  = '25' AND status  != 'closed' AND deleted  = '0' oRdEr bY `169`,`id` asc   limit 0, 20  in lib/dao/dao.class.php on line 1074, last called by lib/dao/dao.class.php on line 526 through function sqlError.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bug&f=browse

18:40:17 Undefined offset: 1 in module/user/control.php on line 712 when visiting /www/index.php?m=user&f=login&referer=L3d3dy9pbmRleC5waHA=

18:41:45 ERROR: SQLSTATE[42S22]: Column not found: 1054 Unknown column '169' in 'order clause'The sql is: SELECT * FROM `zt_bug` wHeRe project IN ('16','14','12','11','10','8','7','6','4','3','2','1','0') AND product  = '25' AND status  != 'closed' AND deleted  = '0' oRdEr bY `169`,`id` asc   limit 0, 20  in lib/dao/dao.class.php on line 1074, last called by lib/dao/dao.class.php on line 526 through function sqlError.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bug&f=browse

18:44:47 ERROR: SQLSTATE[42S22]: Column not found: 1054 Unknown column '169' in 'order clause'The sql is: SELECT * FROM `zt_bug` wHeRe project IN ('16','14','12','11','10','8','7','6','4','3','2','1','0') AND product  = '25' AND status  != 'closed' AND deleted  = '0' oRdEr bY `169`,`id` asc   limit 0, 20  in lib/dao/dao.class.php on line 1074, last called by lib/dao/dao.class.php on line 526 through function sqlError.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bug&f=browse

19:32:58 ERROR: SQLSTATE[42S22]: Column not found: 1054 Unknown column '169' in 'order clause'The sql is: SELECT * FROM `zt_bug` wHeRe project IN ('16','14','12','11','10','8','7','6','4','3','2','1','0') AND product  = '25' AND status  != 'closed' AND deleted  = '0' oRdEr bY `169`,`id` asc   limit 0, 20  in lib/dao/dao.class.php on line 1074, last called by lib/dao/dao.class.php on line 526 through function sqlError.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bug&f=browse

19:33:25 ERROR: SQLSTATE[42S22]: Column not found: 1054 Unknown column '169' in 'order clause'The sql is: SELECT * FROM `zt_bug` wHeRe project IN ('16','14','12','11','10','8','7','6','4','3','2','1','0') AND product  = '25' AND status  != 'closed' AND deleted  = '0' oRdEr bY `169`,`id` asc   limit 0, 20  in lib/dao/dao.class.php on line 1074, last called by lib/dao/dao.class.php on line 526 through function sqlError.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bug&f=browse

19:42:26 Undefined offset: 1 in module/user/control.php on line 712 when visiting /www/index.php?m=user&f=login&referer=L3d3dy9pbmRleC5waHA=

19:43:18 Undefined offset: 1 in module/user/control.php on line 712 when visiting /www/index.php?m=user&f=login&referer=L3d3dy9pbmRleC5waHA=

20:44:30 ERROR: SQLSTATE[42S22]: Column not found: 1054 Unknown column '169' in 'order clause'The sql is: SELECT * FROM `zt_bug` wHeRe project IN ('16','14','12','11','10','8','7','6','4','3','2','1','0') AND product  = '25' AND status  != 'closed' AND deleted  = '0' oRdEr bY `169`,`id` asc   limit 0, 20  in lib/dao/dao.class.php on line 1074, last called by lib/dao/dao.class.php on line 526 through function sqlError.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bug&f=browse

20:55:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

20:55:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=
