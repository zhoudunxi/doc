<?php
 die();
?>

18:46:43 Undefined variable: browseType in module/testcase/view/caseheader.html.php on line 57 when visiting /www/index.php?m=story&f=zeroCase&productID=25

18:46:46 Undefined variable: orderBy in module/testcase/view/caseheader.html.php on line 39 when visiting /www/index.php?m=testcase&f=groupCase&productID=25&branch=0&groupBy=story
