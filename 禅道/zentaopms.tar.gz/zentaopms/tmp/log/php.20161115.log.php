<?php
 die();
?>

19:10:05 Undefined offset: 1 in module/user/control.php on line 712 when visiting /www/index.php?m=user&f=login&referer=L3d3dy9pbmRleC5waHA=

23:27:05 ERROR: the control file module/misci4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=misci4002091i&f=qrCode

23:27:06 ERROR: the control file module/misci4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=misci4002091i&f=qrCode

23:27:08 ERROR: the control file module/misci4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=misci4002091i&f=qrCode

23:27:09 ERROR: the control file module/misc'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=misc'%22%3E%3Ciframe%20onload=alert()%3E&f=qrCode

23:27:14 ERROR: the control file module/misc'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=misc'%22%3E%3Cimg%20src=x%20onerror=prompt()%3E&f=qrCode

23:27:18 ERROR: the control file module/misc'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=misc'%22%3E%3Csvg%20onload=prompt()%3E&f=qrCode

23:27:22 ERROR: the control file module/misci4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=misci4002091i&f=qrCode

23:27:29 ERROR: the control file module/misci4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=misci4002091i&f=qrCode
