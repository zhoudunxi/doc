<?php
 die();
?>

14:26:10 Undefined offset: 1 in module/user/control.php on line 712 when visiting /www/index.php?m=user&f=login&referer=L3d3dy9pbmRleC5waHA=

15:49:26 Undefined offset: 1 in module/user/control.php on line 712 when visiting /www/index.php?m=user&f=login&referer=L3d3dy9pbmRleC5waHA=

23:25:31 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=login&t=mhtml&referer=L3d3dy9pbmRleC5waHA=

23:26:08 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=view&storyID=64

23:26:16 ERROR: the control file module/useri4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=useri4002091i&f=login&t=mhtml&referer=L3d3dy9pbmRleC5waHA=

23:26:22 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=view&storyID=64

23:26:22 ERROR: the control file module/useri4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=useri4002091i&f=login&t=mhtml&referer=L3d3dy9pbmRleC5waHA=

23:26:32 ERROR: the control file module/useri4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=useri4002091i&f=login&t=mhtml&referer=L3d3dy9pbmRleC5waHA=

23:26:36 ERROR: the control file module/user'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=user'%22%3E%3Ciframe%20onload=alert()%3E&f=login&t=mhtml&referer=L3d3dy9pbmRleC5waHA=

23:26:45 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Ciframe%20onload=alert()%3E&f=view&storyID=64

23:27:37 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Cimg%20src=x%20onerror=prompt()%3E&f=view&storyID=64

23:27:38 ERROR: the control file module/user'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=user'%22%3E%3Cimg%20src=x%20onerror=prompt()%3E&f=login&t=mhtml&referer=L3d3dy9pbmRleC5waHA=

23:30:30 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Csvg%20onload=prompt()%3E&f=view&storyID=64

23:31:23 ERROR: the control file module/user'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=user'%22%3E%3Csvg%20onload=prompt()%3E&f=login&t=mhtml&referer=L3d3dy9pbmRleC5waHA=

23:32:11 ERROR: the control file module/storyi4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=storyi4002091i&f=view&storyID=64

23:32:50 ERROR: the control file module/storyi4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=storyi4002091i&f=view&storyID=64
