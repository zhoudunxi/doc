<?php
 die();
?>

09:47:11 Undefined offset: 1 in module/user/control.php on line 712 when visiting /www/index.php?m=user&f=login&referer=L3d3dy9pbmRleC5waHA=

14:35:37 Undefined offset: 1 in module/user/control.php on line 712 when visiting /www/index.php?m=user&f=login&referer=L3d3dy9pbmRleC5waHA=

16:39:11 ERROR: the control file module/${@print(md5(233333))}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D&f=view&storyID=313

16:39:22 ERROR: the control file module/${@print(md5(233333))}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D&f=view&storyID=313

16:39:23 ERROR: the control file module/${@print(md5(233333))}\/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D%5C&f=view&storyID=313

16:39:27 ERROR: the control file module/${@print(md5(233333))}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D&f=view&storyID=313

16:39:29 ERROR: the control file module/${@print(md5(233333))}\/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D%5C&f=view&storyID=313

16:39:33 ERROR: the control file module/print(md5(233333));die();/*/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=print%28md5%28233333%29%29%3Bdie%28%29%3B%2F*&f=view&storyID=313

16:39:34 ERROR: the control file module/print(md5(233333));die();/*/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=print%28md5%28233333%29%29%3Bdie%28%29%3B%2F*&f=view&storyID=313

16:39:40 ERROR: the control file module/${@print(md5(233333))}\/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D%5C&f=view&storyID=313

16:39:53 ERROR: the control file module/${@print(md5(233333))}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D&f=view&storyID=313

16:39:56 ERROR: the control file module/print(md5(233333));die();/*/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=print%28md5%28233333%29%29%3Bdie%28%29%3B%2F*&f=view&storyID=313

16:40:02 ERROR: the control file module/${7387324923+57832091}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7B7387324923%2b57832091%7D&f=view&storyID=313

16:40:06 ERROR: the control file module/${new java.lang.string(new byte[]{97,98,99,100,101,102,120,97,120,102,101,100,99,98,97})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.lang.String(new%20byte%5B%5D%7B97,98,99,100,101,102,120,97,120,102,101,100,99,98,97%7D)%7D&f=view&storyID=313

16:40:06 ERROR: the control file module/${7387324923+57832091}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7B7387324923%2b57832091%7D&f=view&storyID=313

16:40:11 ERROR: the control file module/${@print(md5(233333))}\/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D%5C&f=view&storyID=313

16:40:18 ERROR: the control file module/${new java.lang.string(new byte[]{97,98,99,100,101,102,120,97,120,102,101,100,99,98,97})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.lang.String(new%20byte%5B%5D%7B97,98,99,100,101,102,120,97,120,102,101,100,99,98,97%7D)%7D&f=view&storyID=313

16:40:20 ERROR: the control file module/${new java.net.urlclassloader(new java.net.url[]{}).loadclass(new java.lang.string(new byte[]{111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115})).tostring(new byte[]{35,121,100,118,117,108,116,116,116,35})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.net.URLClassLoader(new%20java.net.URL%5B%5D%7B%7D).loadClass(new%20java.lang.String(new%20byte%5B%5D%7B111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115%7D)).toString(new%20byte%5B%5D%7B35,121,100,118,117,108,116,116,116,35%7D)%7D&f=view&storyID=313

16:40:25 ERROR: the control file module/print(md5(233333));die();/*/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=print%28md5%28233333%29%29%3Bdie%28%29%3B%2F*&f=view&storyID=313

16:40:28 ERROR: the control file module/${new java.net.urlclassloader(new java.net.url[]{}).loadclass(new java.lang.string(new byte[]{111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115})).tostring(new byte[]{35,121,100,118,117,108,116,116,116,35})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.net.URLClassLoader(new%20java.net.URL%5B%5D%7B%7D).loadClass(new%20java.lang.String(new%20byte%5B%5D%7B111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115%7D)).toString(new%20byte%5B%5D%7B35,121,100,118,117,108,116,116,116,35%7D)%7D&f=view&storyID=313

16:40:31 ERROR: the control file module/${7387324923+57832091}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7B7387324923%2b57832091%7D&f=view&storyID=313

16:40:36 ERROR: the control file module/${new java.lang.string(new byte[]{97,98,99,100,101,102,120,97,120,102,101,100,99,98,97})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.lang.String(new%20byte%5B%5D%7B97,98,99,100,101,102,120,97,120,102,101,100,99,98,97%7D)%7D&f=view&storyID=313

16:40:46 ERROR: the control file module/${new java.net.urlclassloader(new java.net.url[]{}).loadclass(new java.lang.string(new byte[]{111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115})).tostring(new byte[]{35,121,100,118,117,108,116,116,116,35})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.net.URLClassLoader(new%20java.net.URL%5B%5D%7B%7D).loadClass(new%20java.lang.String(new%20byte%5B%5D%7B111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115%7D)).toString(new%20byte%5B%5D%7B35,121,100,118,117,108,116,116,116,35%7D)%7D&f=view&storyID=313

16:40:52 ERROR: the control file module/${7387324923+57832091}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7B7387324923%2b57832091%7D&f=view&storyID=313

16:40:57 ERROR: the control file module/${new java.lang.string(new byte[]{97,98,99,100,101,102,120,97,120,102,101,100,99,98,97})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.lang.String(new%20byte%5B%5D%7B97,98,99,100,101,102,120,97,120,102,101,100,99,98,97%7D)%7D&f=view&storyID=313

16:41:04 ERROR: the control file module/${new java.net.urlclassloader(new java.net.url[]{}).loadclass(new java.lang.string(new byte[]{111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115})).tostring(new byte[]{35,121,100,118,117,108,116,116,116,35})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.net.URLClassLoader(new%20java.net.URL%5B%5D%7B%7D).loadClass(new%20java.lang.String(new%20byte%5B%5D%7B111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115%7D)).toString(new%20byte%5B%5D%7B35,121,100,118,117,108,116,116,116,35%7D)%7D&f=view&storyID=313

16:43:34 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Ciframe%20onload=alert()%3E&f=view&storyID=313

16:43:37 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Ciframe%20onload=alert()%3E&f=view&storyID=313

16:43:37 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Ciframe%20onload=alert()%3E&f=view&storyID=313

16:43:38 ERROR: the control file module/${@print(md5(233333))}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D&f=view&storyID=313

16:43:47 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Cimg%20src=x%20onerror=prompt()%3E&f=view&storyID=313

16:43:48 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Cimg%20src=x%20onerror=prompt()%3E&f=view&storyID=313

16:43:50 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Ciframe%20onload=alert()%3E&f=view&storyID=313

16:43:53 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Cimg%20src=x%20onerror=prompt()%3E&f=view&storyID=313

16:43:56 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Csvg%20onload=prompt()%3E&f=view&storyID=313

16:44:00 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Cimg%20src=x%20onerror=prompt()%3E&f=view&storyID=313

16:44:00 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Csvg%20onload=prompt()%3E&f=view&storyID=313

16:44:08 ERROR: the control file module/storyi2027381i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=storyi2027381i&f=view&storyID=313

16:44:08 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Csvg%20onload=prompt()%3E&f=view&storyID=313

16:44:10 ERROR: the control file module/storyi2027381i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=storyi2027381i&f=view&storyID=313

16:44:11 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Csvg%20onload=prompt()%3E&f=view&storyID=313

16:44:14 ERROR: the control file module/storyi2027381i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=storyi2027381i&f=view&storyID=313

16:44:15 ERROR: the control file module/${@print(md5(233333))}\/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D%5C&f=view&storyID=313

16:44:17 ERROR: the control file module/storyi2027381i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=storyi2027381i&f=view&storyID=313

16:44:17 ERROR: the control file module/storyi2027381i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=storyi2027381i&f=view&storyID=313

16:44:24 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=view&storyID=313

16:44:24 ERROR: the control file module/print(md5(233333));die();/*/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=print%28md5%28233333%29%29%3Bdie%28%29%3B%2F*&f=view&storyID=313

16:44:28 ERROR: the control file module/${@print(md5(233333))}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D&f=view&storyID=313

16:44:29 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=view&storyID=313

16:44:32 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=view&storyID=313

16:44:34 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=view&storyID=313

16:44:34 ERROR: the control file module/${@print(md5(233333))}\/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D%5C&f=view&storyID=313

16:44:35 ERROR: the control file module/${7387324923+57832091}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7B7387324923%2b57832091%7D&f=view&storyID=313

16:44:37 ERROR: the control file module/print(md5(233333));die();/*/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=print%28md5%28233333%29%29%3Bdie%28%29%3B%2F*&f=view&storyID=313

16:44:39 ERROR: the control file module/${new java.lang.string(new byte[]{97,98,99,100,101,102,120,97,120,102,101,100,99,98,97})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.lang.String(new%20byte%5B%5D%7B97,98,99,100,101,102,120,97,120,102,101,100,99,98,97%7D)%7D&f=view&storyID=313

16:44:44 ERROR: the control file module/${new java.net.urlclassloader(new java.net.url[]{}).loadclass(new java.lang.string(new byte[]{111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115})).tostring(new byte[]{35,121,100,118,117,108,116,116,116,35})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.net.URLClassLoader(new%20java.net.URL%5B%5D%7B%7D).loadClass(new%20java.lang.String(new%20byte%5B%5D%7B111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115%7D)).toString(new%20byte%5B%5D%7B35,121,100,118,117,108,116,116,116,35%7D)%7D&f=view&storyID=313

16:44:44 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=view&storyID=313

16:44:45 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=view&storyID=313

16:44:48 ERROR: the control file module/${@print(md5(233333))}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D&f=view&storyID=313

16:44:49 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=view&storyID=313

16:44:53 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=view&storyID=313

16:45:02 ERROR: the control file module/${7387324923+57832091}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7B7387324923%2b57832091%7D&f=view&storyID=313

16:45:06 ERROR: the control file module/${new java.lang.string(new byte[]{97,98,99,100,101,102,120,97,120,102,101,100,99,98,97})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.lang.String(new%20byte%5B%5D%7B97,98,99,100,101,102,120,97,120,102,101,100,99,98,97%7D)%7D&f=view&storyID=313

16:45:12 ERROR: the control file module/${@print(md5(233333))}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D&f=view&storyID=313

16:45:14 ERROR: the control file module/${@print(md5(233333))}\/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D%5C&f=view&storyID=313

16:45:17 ERROR: the control file module/${@print(md5(233333))}\/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D%5C&f=view&storyID=313

16:45:17 ERROR: the control file module/print(md5(233333));die();/*/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=print%28md5%28233333%29%29%3Bdie%28%29%3B%2F*&f=view&storyID=313

16:45:21 ERROR: the control file module/${new java.net.urlclassloader(new java.net.url[]{}).loadclass(new java.lang.string(new byte[]{111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115})).tostring(new byte[]{35,121,100,118,117,108,116,116,116,35})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.net.URLClassLoader(new%20java.net.URL%5B%5D%7B%7D).loadClass(new%20java.lang.String(new%20byte%5B%5D%7B111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115%7D)).toString(new%20byte%5B%5D%7B35,121,100,118,117,108,116,116,116,35%7D)%7D&f=view&storyID=313

16:45:22 ERROR: the control file module/${@print(md5(233333))}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D&f=view&storyID=313

16:45:24 ERROR: the control file module/print(md5(233333));die();/*/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=print%28md5%28233333%29%29%3Bdie%28%29%3B%2F*&f=view&storyID=313

16:45:34 ERROR: the control file module/storyi2027381i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=storyi2027381i&f=view&storyID=313

16:45:34 ERROR: the control file module/storyi2027381i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=storyi2027381i&f=view&storyID=313

16:45:35 ERROR: the control file module/storyi2027381i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=storyi2027381i&f=view&storyID=313

16:45:35 ERROR: the control file module/${7387324923+57832091}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7B7387324923%2b57832091%7D&f=view&storyID=313

16:45:35 ERROR: the control file module/storyi2027381i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=storyi2027381i&f=view&storyID=313

16:45:36 ERROR: the control file module/${@print(md5(233333))}\/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D%5C&f=view&storyID=313

16:45:37 ERROR: the control file module/${7387324923+57832091}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7B7387324923%2b57832091%7D&f=view&storyID=313

16:45:40 ERROR: the control file module/${new java.lang.string(new byte[]{97,98,99,100,101,102,120,97,120,102,101,100,99,98,97})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.lang.String(new%20byte%5B%5D%7B97,98,99,100,101,102,120,97,120,102,101,100,99,98,97%7D)%7D&f=view&storyID=313

16:45:42 ERROR: the control file module/${new java.net.urlclassloader(new java.net.url[]{}).loadclass(new java.lang.string(new byte[]{111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115})).tostring(new byte[]{35,121,100,118,117,108,116,116,116,35})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.net.URLClassLoader(new%20java.net.URL%5B%5D%7B%7D).loadClass(new%20java.lang.String(new%20byte%5B%5D%7B111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115%7D)).toString(new%20byte%5B%5D%7B35,121,100,118,117,108,116,116,116,35%7D)%7D&f=view&storyID=313

16:45:44 ERROR: the control file module/print(md5(233333));die();/*/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=print%28md5%28233333%29%29%3Bdie%28%29%3B%2F*&f=view&storyID=313

16:45:45 ERROR: the control file module/${@print(md5(233333))}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D&f=view&storyID=313

16:45:46 ERROR: the control file module/${new java.lang.string(new byte[]{97,98,99,100,101,102,120,97,120,102,101,100,99,98,97})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.lang.String(new%20byte%5B%5D%7B97,98,99,100,101,102,120,97,120,102,101,100,99,98,97%7D)%7D&f=view&storyID=313

16:45:57 ERROR: the control file module/${@print(md5(233333))}\/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D%5C&f=view&storyID=313

16:45:57 ERROR: the control file module/${new java.net.urlclassloader(new java.net.url[]{}).loadclass(new java.lang.string(new byte[]{111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115})).tostring(new byte[]{35,121,100,118,117,108,116,116,116,35})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.net.URLClassLoader(new%20java.net.URL%5B%5D%7B%7D).loadClass(new%20java.lang.String(new%20byte%5B%5D%7B111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115%7D)).toString(new%20byte%5B%5D%7B35,121,100,118,117,108,116,116,116,35%7D)%7D&f=view&storyID=313

16:45:59 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Ciframe%20onload=alert()%3E&f=view&storyID=313

16:46:07 ERROR: the control file module/${7387324923+57832091}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7B7387324923%2b57832091%7D&f=view&storyID=313

16:46:11 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Cimg%20src=x%20onerror=prompt()%3E&f=view&storyID=313

16:46:12 ERROR: the control file module/${new java.lang.string(new byte[]{97,98,99,100,101,102,120,97,120,102,101,100,99,98,97})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.lang.String(new%20byte%5B%5D%7B97,98,99,100,101,102,120,97,120,102,101,100,99,98,97%7D)%7D&f=view&storyID=313

16:46:15 ERROR: the control file module/${new java.net.urlclassloader(new java.net.url[]{}).loadclass(new java.lang.string(new byte[]{111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115})).tostring(new byte[]{35,121,100,118,117,108,116,116,116,35})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.net.URLClassLoader(new%20java.net.URL%5B%5D%7B%7D).loadClass(new%20java.lang.String(new%20byte%5B%5D%7B111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115%7D)).toString(new%20byte%5B%5D%7B35,121,100,118,117,108,116,116,116,35%7D)%7D&f=view&storyID=313

16:46:17 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Csvg%20onload=prompt()%3E&f=view&storyID=313

16:46:18 ERROR: the control file module/print(md5(233333));die();/*/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=print%28md5%28233333%29%29%3Bdie%28%29%3B%2F*&f=view&storyID=313

16:46:26 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Ciframe%20onload=alert()%3E&f=view&storyID=313

16:46:38 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Cimg%20src=x%20onerror=prompt()%3E&f=view&storyID=313

16:46:38 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=view&storyID=313

16:46:43 ERROR: the control file module/${7387324923+57832091}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7B7387324923%2b57832091%7D&f=view&storyID=313

16:46:43 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=view&storyID=313

16:46:46 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Ciframe%20onload=alert()%3E&f=view&storyID=313

16:46:49 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Csvg%20onload=prompt()%3E&f=view&storyID=313

16:46:50 ERROR: the control file module/${new java.lang.string(new byte[]{97,98,99,100,101,102,120,97,120,102,101,100,99,98,97})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.lang.String(new%20byte%5B%5D%7B97,98,99,100,101,102,120,97,120,102,101,100,99,98,97%7D)%7D&f=view&storyID=313

16:46:55 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Cimg%20src=x%20onerror=prompt()%3E&f=view&storyID=313

16:46:59 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=view&storyID=313

16:46:59 ERROR: the control file module/${new java.net.urlclassloader(new java.net.url[]{}).loadclass(new java.lang.string(new byte[]{111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115})).tostring(new byte[]{35,121,100,118,117,108,116,116,116,35})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.net.URLClassLoader(new%20java.net.URL%5B%5D%7B%7D).loadClass(new%20java.lang.String(new%20byte%5B%5D%7B111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115%7D)).toString(new%20byte%5B%5D%7B35,121,100,118,117,108,116,116,116,35%7D)%7D&f=view&storyID=313

16:47:01 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=view&storyID=313

16:47:06 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Csvg%20onload=prompt()%3E&f=view&storyID=313

16:47:17 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Ciframe%20onload=alert()%3E&f=view&storyID=313

16:47:24 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Cimg%20src=x%20onerror=prompt()%3E&f=view&storyID=313

16:47:24 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=view&storyID=313

16:47:29 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=view&storyID=313

16:47:30 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Csvg%20onload=prompt()%3E&f=view&storyID=313

16:47:40 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Ciframe%20onload=alert()%3E&f=view&storyID=313

16:47:42 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=view&storyID=313

16:47:48 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Cimg%20src=x%20onerror=prompt()%3E&f=view&storyID=313

16:47:49 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=view&storyID=313

16:47:55 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Csvg%20onload=prompt()%3E&f=view&storyID=313

16:48:07 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=view&storyID=313

16:48:09 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Ciframe%20onload=alert()%3E&f=view&storyID=313

16:48:12 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=view&storyID=313

16:48:17 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Cimg%20src=x%20onerror=prompt()%3E&f=view&storyID=313

16:48:28 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Csvg%20onload=prompt()%3E&f=view&storyID=313

16:48:42 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=view&storyID=313

16:48:51 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=view&storyID=313
