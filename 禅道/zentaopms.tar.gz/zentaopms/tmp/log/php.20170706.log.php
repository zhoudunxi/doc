<?php
 die();
?>

13:30:46 Undefined offset: 1 in module/user/control.php on line 712 when visiting /www/index.php?m=user&f=login&referer=L3d3dy9pbmRleC5waHA=

23:55:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:55:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=31&module=bug&method=browse&extra=

23:56:17 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/model.php on line 52 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/model.php on line 52 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/model.php on line 53 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/model.php on line 53 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Invalid argument supplied for foreach() in module/project/model.php on line 55 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

23:56:17 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed
