<?php
 die();
?>

16:56:43 ERROR: the control file module/${@print(md5(233333))}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

16:56:44 ERROR: the control file module/${@print(md5(233333))}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

16:57:49 ERROR: the control file module/${@print(md5(233333))}\/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D%5C&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

16:58:17 ERROR: the control file module/print(md5(233333));die();/*/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=print%28md5%28233333%29%29%3Bdie%28%29%3B%2F*&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

16:58:33 ERROR: the control file module/${7387324923+57832091}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7B7387324923%2b57832091%7D&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

16:58:44 ERROR: the control file module/${new java.lang.string(new byte[]{97,98,99,100,101,102,120,97,120,102,101,100,99,98,97})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.lang.String(new%20byte%5B%5D%7B97,98,99,100,101,102,120,97,120,102,101,100,99,98,97%7D)%7D&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

16:58:56 ERROR: the control file module/${new java.net.urlclassloader(new java.net.url[]{}).loadclass(new java.lang.string(new byte[]{111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115})).tostring(new byte[]{35,121,100,118,117,108,116,116,116,35})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.net.URLClassLoader(new%20java.net.URL%5B%5D%7B%7D).loadClass(new%20java.lang.String(new%20byte%5B%5D%7B111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115%7D)).toString(new%20byte%5B%5D%7B35,121,100,118,117,108,116,116,116,35%7D)%7D&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:00:02 ERROR: the control file module/my'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=my'%22%3E%3Ciframe%20onload=alert()%3E&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:00:24 ERROR: the control file module/my'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=my'%22%3E%3Cimg%20src=x%20onerror=prompt()%3E&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:00:44 ERROR: the control file module/my'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=my'%22%3E%3Csvg%20onload=prompt()%3E&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:01:07 ERROR: the control file module/myi2027381i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=myi2027381i&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:01:08 ERROR: the control file module/myi2027381i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=myi2027381i&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:01:09 ERROR: the control file module/myi2027381i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=myi2027381i&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:01:11 ERROR: the control file module/myi2027381i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=myi2027381i&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:01:14 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:01:34 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:01:55 ERROR: the control file module/${@print(md5(233333))}\/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D%5C&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:02:06 ERROR: the control file module/myi2027381i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=myi2027381i&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:02:29 ERROR: the control file module/${@print(md5(233333))}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D&f=view&storyID=313

17:02:31 ERROR: the control file module/${@print(md5(233333))}\/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D%5C&f=view&storyID=313

17:02:34 ERROR: the control file module/print(md5(233333));die();/*/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=print%28md5%28233333%29%29%3Bdie%28%29%3B%2F*&f=view&storyID=313

17:02:44 ERROR: the control file module/${7387324923+57832091}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7B7387324923%2b57832091%7D&f=view&storyID=313

17:02:47 ERROR: the control file module/${new java.lang.string(new byte[]{97,98,99,100,101,102,120,97,120,102,101,100,99,98,97})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.lang.String(new%20byte%5B%5D%7B97,98,99,100,101,102,120,97,120,102,101,100,99,98,97%7D)%7D&f=view&storyID=313

17:02:50 ERROR: the control file module/${new java.net.urlclassloader(new java.net.url[]{}).loadclass(new java.lang.string(new byte[]{111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115})).tostring(new byte[]{35,121,100,118,117,108,116,116,116,35})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.net.URLClassLoader(new%20java.net.URL%5B%5D%7B%7D).loadClass(new%20java.lang.String(new%20byte%5B%5D%7B111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115%7D)).toString(new%20byte%5B%5D%7B35,121,100,118,117,108,116,116,116,35%7D)%7D&f=view&storyID=313

17:03:01 ERROR: the control file module/${@print(md5(233333))}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:03:13 ERROR: the control file module/print(md5(233333));die();/*/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=print%28md5%28233333%29%29%3Bdie%28%29%3B%2F*&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:03:14 ERROR: the control file module/${@print(md5(233333))}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D&f=view&storyID=313

17:03:22 ERROR: the control file module/${@print(md5(233333))}\/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D%5C&f=view&storyID=313

17:03:31 ERROR: the control file module/print(md5(233333));die();/*/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=print%28md5%28233333%29%29%3Bdie%28%29%3B%2F*&f=view&storyID=313

17:03:45 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Ciframe%20onload=alert()%3E&f=view&storyID=313

17:03:49 ERROR: the control file module/${7387324923+57832091}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7B7387324923%2b57832091%7D&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:03:52 ERROR: the control file module/${7387324923+57832091}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7B7387324923%2b57832091%7D&f=view&storyID=313

17:03:52 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Cimg%20src=x%20onerror=prompt()%3E&f=view&storyID=313

17:03:58 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Csvg%20onload=prompt()%3E&f=view&storyID=313

17:04:00 ERROR: the control file module/${new java.lang.string(new byte[]{97,98,99,100,101,102,120,97,120,102,101,100,99,98,97})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.lang.String(new%20byte%5B%5D%7B97,98,99,100,101,102,120,97,120,102,101,100,99,98,97%7D)%7D&f=view&storyID=313

17:04:08 ERROR: the control file module/${new java.net.urlclassloader(new java.net.url[]{}).loadclass(new java.lang.string(new byte[]{111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115})).tostring(new byte[]{35,121,100,118,117,108,116,116,116,35})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.net.URLClassLoader(new%20java.net.URL%5B%5D%7B%7D).loadClass(new%20java.lang.String(new%20byte%5B%5D%7B111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115%7D)).toString(new%20byte%5B%5D%7B35,121,100,118,117,108,116,116,116,35%7D)%7D&f=view&storyID=313

17:04:09 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=view&storyID=313

17:04:12 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=view&storyID=313

17:04:17 ERROR: the control file module/${@print(md5(233333))}\/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D%5C&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:04:23 ERROR: the control file module/${new java.lang.string(new byte[]{97,98,99,100,101,102,120,97,120,102,101,100,99,98,97})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.lang.String(new%20byte%5B%5D%7B97,98,99,100,101,102,120,97,120,102,101,100,99,98,97%7D)%7D&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:04:25 ERROR: the control file module/${@print(md5(233333))}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D&f=view&storyID=313

17:04:34 ERROR: the control file module/${@print(md5(233333))}\/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D%5C&f=view&storyID=313

17:04:42 ERROR: the control file module/${new java.net.urlclassloader(new java.net.url[]{}).loadclass(new java.lang.string(new byte[]{111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115})).tostring(new byte[]{35,121,100,118,117,108,116,116,116,35})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.net.URLClassLoader(new%20java.net.URL%5B%5D%7B%7D).loadClass(new%20java.lang.String(new%20byte%5B%5D%7B111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115%7D)).toString(new%20byte%5B%5D%7B35,121,100,118,117,108,116,116,116,35%7D)%7D&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:04:49 ERROR: the control file module/print(md5(233333));die();/*/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=print%28md5%28233333%29%29%3Bdie%28%29%3B%2F*&f=view&storyID=313

17:05:11 ERROR: the control file module/print(md5(233333));die();/*/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=print%28md5%28233333%29%29%3Bdie%28%29%3B%2F*&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:05:15 ERROR: the control file module/${7387324923+57832091}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7B7387324923%2b57832091%7D&f=view&storyID=313

17:05:20 ERROR: the control file module/${new java.lang.string(new byte[]{97,98,99,100,101,102,120,97,120,102,101,100,99,98,97})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.lang.String(new%20byte%5B%5D%7B97,98,99,100,101,102,120,97,120,102,101,100,99,98,97%7D)%7D&f=view&storyID=313

17:05:26 ERROR: the control file module/${new java.net.urlclassloader(new java.net.url[]{}).loadclass(new java.lang.string(new byte[]{111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115})).tostring(new byte[]{35,121,100,118,117,108,116,116,116,35})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.net.URLClassLoader(new%20java.net.URL%5B%5D%7B%7D).loadClass(new%20java.lang.String(new%20byte%5B%5D%7B111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115%7D)).toString(new%20byte%5B%5D%7B35,121,100,118,117,108,116,116,116,35%7D)%7D&f=view&storyID=313

17:05:42 ERROR: the control file module/${7387324923+57832091}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7B7387324923%2b57832091%7D&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:06:12 ERROR: the control file module/${new java.lang.string(new byte[]{97,98,99,100,101,102,120,97,120,102,101,100,99,98,97})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.lang.String(new%20byte%5B%5D%7B97,98,99,100,101,102,120,97,120,102,101,100,99,98,97%7D)%7D&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:06:24 ERROR: the control file module/${new java.net.urlclassloader(new java.net.url[]{}).loadclass(new java.lang.string(new byte[]{111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115})).tostring(new byte[]{35,121,100,118,117,108,116,116,116,35})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.net.URLClassLoader(new%20java.net.URL%5B%5D%7B%7D).loadClass(new%20java.lang.String(new%20byte%5B%5D%7B111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115%7D)).toString(new%20byte%5B%5D%7B35,121,100,118,117,108,116,116,116,35%7D)%7D&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:06:46 ERROR: the control file module/my'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=my'%22%3E%3Ciframe%20onload=alert()%3E&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:06:47 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Ciframe%20onload=alert()%3E&f=view&storyID=313

17:06:56 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Cimg%20src=x%20onerror=prompt()%3E&f=view&storyID=313

17:07:04 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Csvg%20onload=prompt()%3E&f=view&storyID=313

17:07:05 ERROR: the control file module/my'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=my'%22%3E%3Cimg%20src=x%20onerror=prompt()%3E&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:07:17 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Ciframe%20onload=alert()%3E&f=view&storyID=313

17:07:26 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Cimg%20src=x%20onerror=prompt()%3E&f=view&storyID=313

17:07:36 ERROR: the control file module/${@print(md5(233333))}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:07:36 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Csvg%20onload=prompt()%3E&f=view&storyID=313

17:07:37 ERROR: the control file module/my'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=my'%22%3E%3Ciframe%20onload=alert()%3E&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:07:52 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=view&storyID=313

17:08:03 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=view&storyID=313

17:08:03 ERROR: the control file module/${@print(md5(233333))}\/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D%5C&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:08:33 ERROR: the control file module/print(md5(233333));die();/*/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=print%28md5%28233333%29%29%3Bdie%28%29%3B%2F*&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:08:37 ERROR: the control file module/my'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=my'%22%3E%3Cimg%20src=x%20onerror=prompt()%3E&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:08:57 ERROR: the control file module/my'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=my'%22%3E%3Csvg%20onload=prompt()%3E&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:09:24 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:09:50 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:10:09 ERROR: the control file module/${7387324923+57832091}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7B7387324923%2b57832091%7D&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:10:16 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=view&storyID=313

17:10:51 ERROR: the control file module/${new java.lang.string(new byte[]{97,98,99,100,101,102,120,97,120,102,101,100,99,98,97})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.lang.String(new%20byte%5B%5D%7B97,98,99,100,101,102,120,97,120,102,101,100,99,98,97%7D)%7D&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:11:05 ERROR: the control file module/${new java.net.urlclassloader(new java.net.url[]{}).loadclass(new java.lang.string(new byte[]{111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115})).tostring(new byte[]{35,121,100,118,117,108,116,116,116,35})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.net.URLClassLoader(new%20java.net.URL%5B%5D%7B%7D).loadClass(new%20java.lang.String(new%20byte%5B%5D%7B111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115%7D)).toString(new%20byte%5B%5D%7B35,121,100,118,117,108,116,116,116,35%7D)%7D&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:11:32 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=view&storyID=313

17:12:00 ERROR: the control file module/my'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=my'%22%3E%3Csvg%20onload=prompt()%3E&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:12:07 ERROR: the control file module/my'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=my'%22%3E%3Ciframe%20onload=alert()%3E&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:12:36 ERROR: the control file module/${@print(md5(233333))}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D&f=view&storyID=313

17:12:40 ERROR: the control file module/${@print(md5(233333))}\/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D%5C&f=view&storyID=313

17:12:42 ERROR: the control file module/my'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=my'%22%3E%3Cimg%20src=x%20onerror=prompt()%3E&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:12:50 ERROR: the control file module/print(md5(233333));die();/*/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=print%28md5%28233333%29%29%3Bdie%28%29%3B%2F*&f=view&storyID=313

17:13:07 ERROR: the control file module/my'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=my'%22%3E%3Csvg%20onload=prompt()%3E&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:13:09 ERROR: the control file module/${7387324923+57832091}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7B7387324923%2b57832091%7D&f=view&storyID=313

17:13:12 ERROR: the control file module/${new java.lang.string(new byte[]{97,98,99,100,101,102,120,97,120,102,101,100,99,98,97})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.lang.String(new%20byte%5B%5D%7B97,98,99,100,101,102,120,97,120,102,101,100,99,98,97%7D)%7D&f=view&storyID=313

17:13:15 ERROR: the control file module/${new java.net.urlclassloader(new java.net.url[]{}).loadclass(new java.lang.string(new byte[]{111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115})).tostring(new byte[]{35,121,100,118,117,108,116,116,116,35})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.net.URLClassLoader(new%20java.net.URL%5B%5D%7B%7D).loadClass(new%20java.lang.String(new%20byte%5B%5D%7B111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115%7D)).toString(new%20byte%5B%5D%7B35,121,100,118,117,108,116,116,116,35%7D)%7D&f=view&storyID=313

17:13:34 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:13:56 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:14:22 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:14:46 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=bug&type=assignedTo&orderBy=assignedTo_desc&recTotal=0&recPerPage=20&pageID=1

17:15:27 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Ciframe%20onload=alert()%3E&f=view&storyID=313

17:15:38 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Cimg%20src=x%20onerror=prompt()%3E&f=view&storyID=313

17:15:44 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Csvg%20onload=prompt()%3E&f=view&storyID=313

17:16:00 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=view&storyID=313

17:16:06 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=view&storyID=313
