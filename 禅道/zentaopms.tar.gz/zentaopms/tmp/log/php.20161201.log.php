<?php
 die();
?>

21:46:49 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=manageMembers&t=html&project=10&teamImport=9

21:47:21 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=manageMembers&t=html&project=10&teamImport=9

21:47:50 ERROR: the control file module/projecti4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=projecti4002091i&f=manageMembers&t=html&project=10&teamImport=9

21:47:53 ERROR: the control file module/projecti4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=projecti4002091i&f=manageMembers&t=html&project=10&teamImport=9

21:50:32 ERROR: the control file module/'"/>/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m='%22/%3E%3C/body%3E%3Cbody+onload=prompt()%3E&f=manageMembers&t=html&project=10&teamImport=9

21:50:55 ERROR: the control file module/'"/>/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%27%22%2f%3E%3C%2fbody%3E%3Cbody%20onload%3dprompt%28%29%3e&f=manageMembers&t=html&project=10&teamImport=9

21:55:14 ERROR: the control file module/%27%22%2f%3e%3c%2fbody%3e%3cbody%20onload%3dprompt%28%29%3e/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%2527%2522%252f%253E%253C%252fbody%253E%253Cbody%2520onload%253dprompt%2528%2529%253e&f=manageMembers&t=html&project=10&teamImport=9

22:23:54 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=ajaxGetProjectBuilds&t=html&projectID=10&productID=14&varName=testTaskBuild&build=0

22:44:42 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=ajaxGetProjectBuilds&t=html&projectID=10&productID=14&varName=testTaskBuild&build=0

22:47:53 ERROR: the control file module/project'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=project'%22%3E%3Ciframe%20onload=alert()%3E&f=manageMembers&t=html&project=10&teamImport=9

22:56:37 ERROR: the control file module/buildi4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=buildi4002091i&f=ajaxGetProjectBuilds&t=html&projectID=10&productID=14&varName=testTaskBuild&build=0

23:17:19 ERROR: the control file module/project'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=project'%22%3E%3Cimg%20src=x%20onerror=prompt()%3E&f=manageMembers&t=html&project=10&teamImport=9

23:45:14 ERROR: the control file module/build'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=build'%22%3E%3Cimg%20src=x%20onerror=prompt()%3E&f=ajaxGetProjectBuilds&t=html&projectID=10&productID=14&varName=testTaskBuild&build=0
