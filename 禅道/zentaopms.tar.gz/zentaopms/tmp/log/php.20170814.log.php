<?php
 die();
?>

11:39:03 Undefined index: branch in module/project/model.php on line 837 when visiting /www/index.php?m=project&f=create

11:39:12 Undefined index: branch in module/project/model.php on line 837 when visiting /www/index.php?m=project&f=create

11:39:20 Undefined index: branch in module/project/model.php on line 837 when visiting /www/index.php?m=project&f=create

11:45:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=product&method=browse&extra=

11:45:54 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/model.php on line 52 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/model.php on line 52 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/model.php on line 53 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/model.php on line 53 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Invalid argument supplied for foreach() in module/project/model.php on line 55 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:45:54 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=18&module=project&method=task&extra=unclosed

11:47:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:47:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

11:49:56 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/model.php on line 52 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/model.php on line 52 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/model.php on line 53 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/model.php on line 53 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Invalid argument supplied for foreach() in module/project/model.php on line 55 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

11:49:56 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=19&module=project&method=task&extra=unclosed

18:09:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:11 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=34&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:09:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=32&module=bug&method=browse&extra=

18:17:39 ERROR: SQLSTATE[23000]: Integrity constraint violation: 1062 Duplicate entry 'tangbing-1' for key 'account'The sql is: INSERT INTO `zt_usergroup` SET `account` = 'tangbing',`group` = '1' in lib/dao/dao.class.php on line 1074, last called by lib/dao/dao.class.php on line 599 through function sqlError.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=user&f=edit&userID=102&from=company

18:24:12 Undefined index: tangbin in module/bug/view/view.html.php on line 177 when visiting /www/index.php?m=bug&f=view&bugID=6311

18:31:22 Undefined offset: 1 in module/user/control.php on line 712 when visiting /www/index.php?m=user&f=login&t=mhtml&referer=L3d3dy9pbmRleC5waHA=
