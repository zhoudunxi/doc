<?php
 die();
?>

10:39:35 Undefined property: router::$user in module/user/view/deny.html.php on line 15 when visiting /www/index.php?m=user&f=deny&module=index&method=index

10:39:35 Trying to get property of non-object in module/user/view/deny.html.php on line 15 when visiting /www/index.php?m=user&f=deny&module=index&method=index

10:39:38 Undefined property: router::$user in module/user/view/deny.html.php on line 15 when visiting /www/index.php?m=user&f=deny&module=index&method=index

10:39:38 Trying to get property of non-object in module/user/view/deny.html.php on line 15 when visiting /www/index.php?m=user&f=deny&module=index&method=index

11:22:02 Trying to get property of non-object in module/testcase/control.php on line 351 when visiting /www/index.php?m=testcase&f=create&productID=13&branch=0&moduleID=0&from=&param=0&storyID=284

16:40:50 Trying to get property of non-object in module/testcase/control.php on line 351 when visiting /www/index.php?m=testcase&f=create&productID=13&branch=0&module=0&from=&param=0&story=286
