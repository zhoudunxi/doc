<?php
 die();
?>

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:16 Undefined offset: 60 in module/testcase/model.php on line 468 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:18 Undefined offset: 60 in module/testcase/model.php on line 569 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:18 Invalid argument supplied for foreach() in module/testcase/model.php on line 569 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:18 Unknown: Input variables exceeded 1000. To increase the limit change max_input_vars in php.ini. in Unknown on line 0 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:51 Undefined offset: 60 in module/testcase/model.php on line 468 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:52 Undefined offset: 60 in module/testcase/model.php on line 569 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:52 Invalid argument supplied for foreach() in module/testcase/model.php on line 569 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:53:52 Unknown: Input variables exceeded 1000. To increase the limit change max_input_vars in php.ini. in Unknown on line 0 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

16:57:53 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:37 Undefined offset: 60 in module/testcase/model.php on line 468 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:38 Undefined offset: 60 in module/testcase/model.php on line 569 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:38 Invalid argument supplied for foreach() in module/testcase/model.php on line 569 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:01:38 Unknown: Input variables exceeded 1000. To increase the limit change max_input_vars in php.ini. in Unknown on line 0 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined property: stdClass::$story in module/testcase/model.php on line 461 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:02:59 Undefined offset: 60 in module/testcase/model.php on line 468 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:03:01 Undefined offset: 60 in module/testcase/model.php on line 569 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:03:01 Invalid argument supplied for foreach() in module/testcase/model.php on line 569 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:03:01 Unknown: Input variables exceeded 1000. To increase the limit change max_input_vars in php.ini. in Unknown on line 0 when visiting /www/index.php?m=testcase&f=showImport&productID=45&branch=0

17:17:31 Undefined index: branch in module/testcase/control.php on line 265 when visiting /www/index.php?m=testcase&f=create&productID=45&branch=0&moduleID=0
