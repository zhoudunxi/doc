<?php
 die();
?>

15:37:29 Trying to get property of non-object in module/testcase/control.php on line 351 when visiting /www/index.php?m=testcase&f=create&productID=13&branch=0&moduleID=0&from=&param=0&storyID=301
