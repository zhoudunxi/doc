<?php
 die();
?>

00:02:44 ERROR: the control file module/project'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=project'%22%3E%3Csvg%20onload=prompt()%3E&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task&extra=unclosed

00:09:25 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu'%22%3E%3Csvg%20onload=prompt()%3E&t=html&objectID=9&module=project&method=task&extra=unclosed

00:09:25 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu'%22%3E%3Csvg%20onload=prompt()%3E&t=html&objectID=9&module=project&method=task&extra=unclosed

00:09:25 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu'%22%3E%3Csvg%20onload=prompt()%3E&t=html&objectID=9&module=project&method=task&extra=unclosed

00:09:25 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu'%22%3E%3Csvg%20onload=prompt()%3E&t=html&objectID=9&module=project&method=task&extra=unclosed

00:09:25 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu'%22%3E%3Csvg%20onload=prompt()%3E&t=html&objectID=9&module=project&method=task&extra=unclosed

00:09:25 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu'%22%3E%3Csvg%20onload=prompt()%3E&t=html&objectID=9&module=project&method=task&extra=unclosed

00:09:25 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu'%22%3E%3Csvg%20onload=prompt()%3E&t=html&objectID=9&module=project&method=task&extra=unclosed

00:09:25 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu'%22%3E%3Csvg%20onload=prompt()%3E&t=html&objectID=9&module=project&method=task&extra=unclosed

00:09:25 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu'%22%3E%3Csvg%20onload=prompt()%3E&t=html&objectID=9&module=project&method=task&extra=unclosed

00:09:25 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu'%22%3E%3Csvg%20onload=prompt()%3E&t=html&objectID=9&module=project&method=task&extra=unclosed

00:09:25 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu'%22%3E%3Csvg%20onload=prompt()%3E&t=html&objectID=9&module=project&method=task&extra=unclosed

00:09:25 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu'%22%3E%3Csvg%20onload=prompt()%3E&t=html&objectID=9&module=project&method=task&extra=unclosed

00:09:25 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu'%22%3E%3Csvg%20onload=prompt()%3E&t=html&objectID=9&module=project&method=task&extra=unclosed

00:09:25 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu'%22%3E%3Csvg%20onload=prompt()%3E&t=html&objectID=9&module=project&method=task&extra=unclosed

00:09:25 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu'%22%3E%3Csvg%20onload=prompt()%3E&t=html&objectID=9&module=project&method=task&extra=unclosed

00:09:25 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu'%22%3E%3Csvg%20onload=prompt()%3E&t=html&objectID=9&module=project&method=task&extra=unclosed

00:09:25 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu'%22%3E%3Csvg%20onload=prompt()%3E&t=html&objectID=9&module=project&method=task&extra=unclosed

00:09:25 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu'%22%3E%3Csvg%20onload=prompt()%3E&t=html&objectID=9&module=project&method=task&extra=unclosed

00:09:25 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu'%22%3E%3Csvg%20onload=prompt()%3E&t=html&objectID=9&module=project&method=task&extra=unclosed

00:09:25 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu'%22%3E%3Csvg%20onload=prompt()%3E&t=html&objectID=9&module=project&method=task&extra=unclosed

00:09:25 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu'%22%3E%3Csvg%20onload=prompt()%3E&t=html&objectID=9&module=project&method=task&extra=unclosed

00:09:25 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu'%22%3E%3Csvg%20onload=prompt()%3E&t=html&objectID=9&module=project&method=task&extra=unclosed

00:09:25 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu'%22%3E%3Csvg%20onload=prompt()%3E&t=html&objectID=9&module=project&method=task&extra=unclosed

00:09:25 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu'%22%3E%3Csvg%20onload=prompt()%3E&t=html&objectID=9&module=project&method=task&extra=unclosed

00:09:25 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu'%22%3E%3Csvg%20onload=prompt()%3E&t=html&objectID=9&module=project&method=task&extra=unclosed

00:09:25 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu'%22%3E%3Csvg%20onload=prompt()%3E&t=html&objectID=9&module=project&method=task&extra=unclosed

00:09:25 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu'%22%3E%3Csvg%20onload=prompt()%3E&t=html&objectID=9&module=project&method=task&extra=unclosed

00:09:25 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu'%22%3E%3Csvg%20onload=prompt()%3E&t=html&objectID=9&module=project&method=task&extra=unclosed

00:09:25 Undefined property: router::$user in module/project/model.php on line 52 when visiting /www/index.php?m=project&f=ajaxGetDropMenu'%22%3E%3Csvg%20onload=prompt()%3E&t=html&objectID=9&module=project&method=task&extra=unclosed

00:09:25 Trying to get property of non-object in module/project/model.php on line 52 when visiting /www/index.php?m=project&f=ajaxGetDropMenu'%22%3E%3Csvg%20onload=prompt()%3E&t=html&objectID=9&module=project&method=task&extra=unclosed

00:09:25 Undefined property: router::$user in module/project/model.php on line 53 when visiting /www/index.php?m=project&f=ajaxGetDropMenu'%22%3E%3Csvg%20onload=prompt()%3E&t=html&objectID=9&module=project&method=task&extra=unclosed

00:09:25 Trying to get property of non-object in module/project/model.php on line 53 when visiting /www/index.php?m=project&f=ajaxGetDropMenu'%22%3E%3Csvg%20onload=prompt()%3E&t=html&objectID=9&module=project&method=task&extra=unclosed

00:09:25 Invalid argument supplied for foreach() in module/project/model.php on line 55 when visiting /www/index.php?m=project&f=ajaxGetDropMenu'%22%3E%3Csvg%20onload=prompt()%3E&t=html&objectID=9&module=project&method=task&extra=unclosed

00:09:25 ERROR: the module project has no ajaxgetdropmenu'"> method in framework/router.class.php on line 1131, last called by www/index.php on line 70 through function loadModule.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=project&f=ajaxGetDropMenu'%22%3E%3Csvg%20onload=prompt()%3E&t=html&objectID=9&module=project&method=task&extra=unclosed

00:20:50 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9'%22%3E%3Csvg%20onload=prompt()%3E&module=project&method=task&extra=unclosed

00:20:50 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9'%22%3E%3Csvg%20onload=prompt()%3E&module=project&method=task&extra=unclosed

00:20:50 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9'%22%3E%3Csvg%20onload=prompt()%3E&module=project&method=task&extra=unclosed

00:20:50 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9'%22%3E%3Csvg%20onload=prompt()%3E&module=project&method=task&extra=unclosed

00:20:50 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9'%22%3E%3Csvg%20onload=prompt()%3E&module=project&method=task&extra=unclosed

00:20:50 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9'%22%3E%3Csvg%20onload=prompt()%3E&module=project&method=task&extra=unclosed

00:20:50 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9'%22%3E%3Csvg%20onload=prompt()%3E&module=project&method=task&extra=unclosed

00:20:50 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9'%22%3E%3Csvg%20onload=prompt()%3E&module=project&method=task&extra=unclosed

00:20:50 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9'%22%3E%3Csvg%20onload=prompt()%3E&module=project&method=task&extra=unclosed

00:20:50 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9'%22%3E%3Csvg%20onload=prompt()%3E&module=project&method=task&extra=unclosed

00:20:50 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9'%22%3E%3Csvg%20onload=prompt()%3E&module=project&method=task&extra=unclosed

00:20:50 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9'%22%3E%3Csvg%20onload=prompt()%3E&module=project&method=task&extra=unclosed

00:20:50 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9'%22%3E%3Csvg%20onload=prompt()%3E&module=project&method=task&extra=unclosed

00:20:50 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9'%22%3E%3Csvg%20onload=prompt()%3E&module=project&method=task&extra=unclosed

00:20:50 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9'%22%3E%3Csvg%20onload=prompt()%3E&module=project&method=task&extra=unclosed

00:20:50 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9'%22%3E%3Csvg%20onload=prompt()%3E&module=project&method=task&extra=unclosed

00:20:50 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9'%22%3E%3Csvg%20onload=prompt()%3E&module=project&method=task&extra=unclosed

00:20:50 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9'%22%3E%3Csvg%20onload=prompt()%3E&module=project&method=task&extra=unclosed

00:20:50 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9'%22%3E%3Csvg%20onload=prompt()%3E&module=project&method=task&extra=unclosed

00:20:50 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9'%22%3E%3Csvg%20onload=prompt()%3E&module=project&method=task&extra=unclosed

00:20:50 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9'%22%3E%3Csvg%20onload=prompt()%3E&module=project&method=task&extra=unclosed

00:20:50 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9'%22%3E%3Csvg%20onload=prompt()%3E&module=project&method=task&extra=unclosed

00:20:50 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9'%22%3E%3Csvg%20onload=prompt()%3E&module=project&method=task&extra=unclosed

00:20:50 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9'%22%3E%3Csvg%20onload=prompt()%3E&module=project&method=task&extra=unclosed

00:20:50 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9'%22%3E%3Csvg%20onload=prompt()%3E&module=project&method=task&extra=unclosed

00:20:50 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9'%22%3E%3Csvg%20onload=prompt()%3E&module=project&method=task&extra=unclosed

00:20:50 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9'%22%3E%3Csvg%20onload=prompt()%3E&module=project&method=task&extra=unclosed

00:20:50 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9'%22%3E%3Csvg%20onload=prompt()%3E&module=project&method=task&extra=unclosed

00:20:50 Undefined property: router::$user in module/project/model.php on line 52 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9'%22%3E%3Csvg%20onload=prompt()%3E&module=project&method=task&extra=unclosed

00:20:50 Trying to get property of non-object in module/project/model.php on line 52 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9'%22%3E%3Csvg%20onload=prompt()%3E&module=project&method=task&extra=unclosed

00:20:50 Undefined property: router::$user in module/project/model.php on line 53 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9'%22%3E%3Csvg%20onload=prompt()%3E&module=project&method=task&extra=unclosed

00:20:50 Trying to get property of non-object in module/project/model.php on line 53 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9'%22%3E%3Csvg%20onload=prompt()%3E&module=project&method=task&extra=unclosed

00:20:50 Invalid argument supplied for foreach() in module/project/model.php on line 55 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9'%22%3E%3Csvg%20onload=prompt()%3E&module=project&method=task&extra=unclosed

00:32:26 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task'%22%3E%3Csvg%20onload=prompt()%3E&extra=unclosed

00:32:26 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task'%22%3E%3Csvg%20onload=prompt()%3E&extra=unclosed

00:32:26 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task'%22%3E%3Csvg%20onload=prompt()%3E&extra=unclosed

00:32:26 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task'%22%3E%3Csvg%20onload=prompt()%3E&extra=unclosed

00:32:26 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task'%22%3E%3Csvg%20onload=prompt()%3E&extra=unclosed

00:32:26 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task'%22%3E%3Csvg%20onload=prompt()%3E&extra=unclosed

00:32:26 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task'%22%3E%3Csvg%20onload=prompt()%3E&extra=unclosed

00:32:26 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task'%22%3E%3Csvg%20onload=prompt()%3E&extra=unclosed

00:32:26 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task'%22%3E%3Csvg%20onload=prompt()%3E&extra=unclosed

00:32:26 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task'%22%3E%3Csvg%20onload=prompt()%3E&extra=unclosed

00:32:26 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task'%22%3E%3Csvg%20onload=prompt()%3E&extra=unclosed

00:32:26 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task'%22%3E%3Csvg%20onload=prompt()%3E&extra=unclosed

00:32:26 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task'%22%3E%3Csvg%20onload=prompt()%3E&extra=unclosed

00:32:26 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task'%22%3E%3Csvg%20onload=prompt()%3E&extra=unclosed

00:32:26 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task'%22%3E%3Csvg%20onload=prompt()%3E&extra=unclosed

00:32:26 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task'%22%3E%3Csvg%20onload=prompt()%3E&extra=unclosed

00:32:26 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task'%22%3E%3Csvg%20onload=prompt()%3E&extra=unclosed

00:32:26 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task'%22%3E%3Csvg%20onload=prompt()%3E&extra=unclosed

00:32:26 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task'%22%3E%3Csvg%20onload=prompt()%3E&extra=unclosed

00:32:26 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task'%22%3E%3Csvg%20onload=prompt()%3E&extra=unclosed

00:32:26 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task'%22%3E%3Csvg%20onload=prompt()%3E&extra=unclosed

00:32:26 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task'%22%3E%3Csvg%20onload=prompt()%3E&extra=unclosed

00:32:26 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task'%22%3E%3Csvg%20onload=prompt()%3E&extra=unclosed

00:32:26 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task'%22%3E%3Csvg%20onload=prompt()%3E&extra=unclosed

00:32:26 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task'%22%3E%3Csvg%20onload=prompt()%3E&extra=unclosed

00:32:26 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task'%22%3E%3Csvg%20onload=prompt()%3E&extra=unclosed

00:32:26 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task'%22%3E%3Csvg%20onload=prompt()%3E&extra=unclosed

00:32:26 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task'%22%3E%3Csvg%20onload=prompt()%3E&extra=unclosed

00:32:26 Undefined property: router::$user in module/project/model.php on line 52 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task'%22%3E%3Csvg%20onload=prompt()%3E&extra=unclosed

00:32:26 Trying to get property of non-object in module/project/model.php on line 52 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task'%22%3E%3Csvg%20onload=prompt()%3E&extra=unclosed

00:32:26 Undefined property: router::$user in module/project/model.php on line 53 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task'%22%3E%3Csvg%20onload=prompt()%3E&extra=unclosed

00:32:26 Trying to get property of non-object in module/project/model.php on line 53 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task'%22%3E%3Csvg%20onload=prompt()%3E&extra=unclosed

00:32:26 Invalid argument supplied for foreach() in module/project/model.php on line 55 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task'%22%3E%3Csvg%20onload=prompt()%3E&extra=unclosed

00:40:18 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task&extra=unclosed'%22%3E%3Csvg%20onload=prompt()%3E

00:40:18 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task&extra=unclosed'%22%3E%3Csvg%20onload=prompt()%3E

00:40:18 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task&extra=unclosed'%22%3E%3Csvg%20onload=prompt()%3E

00:40:18 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task&extra=unclosed'%22%3E%3Csvg%20onload=prompt()%3E

00:40:18 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task&extra=unclosed'%22%3E%3Csvg%20onload=prompt()%3E

00:40:18 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task&extra=unclosed'%22%3E%3Csvg%20onload=prompt()%3E

00:40:18 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task&extra=unclosed'%22%3E%3Csvg%20onload=prompt()%3E

00:40:18 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task&extra=unclosed'%22%3E%3Csvg%20onload=prompt()%3E

00:40:18 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task&extra=unclosed'%22%3E%3Csvg%20onload=prompt()%3E

00:40:18 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task&extra=unclosed'%22%3E%3Csvg%20onload=prompt()%3E

00:40:18 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task&extra=unclosed'%22%3E%3Csvg%20onload=prompt()%3E

00:40:18 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task&extra=unclosed'%22%3E%3Csvg%20onload=prompt()%3E

00:40:18 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task&extra=unclosed'%22%3E%3Csvg%20onload=prompt()%3E

00:40:18 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task&extra=unclosed'%22%3E%3Csvg%20onload=prompt()%3E

00:40:18 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task&extra=unclosed'%22%3E%3Csvg%20onload=prompt()%3E

00:40:18 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task&extra=unclosed'%22%3E%3Csvg%20onload=prompt()%3E

00:40:18 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task&extra=unclosed'%22%3E%3Csvg%20onload=prompt()%3E

00:40:18 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task&extra=unclosed'%22%3E%3Csvg%20onload=prompt()%3E

00:40:18 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task&extra=unclosed'%22%3E%3Csvg%20onload=prompt()%3E

00:40:18 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task&extra=unclosed'%22%3E%3Csvg%20onload=prompt()%3E

00:40:18 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task&extra=unclosed'%22%3E%3Csvg%20onload=prompt()%3E

00:40:18 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task&extra=unclosed'%22%3E%3Csvg%20onload=prompt()%3E

00:40:18 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task&extra=unclosed'%22%3E%3Csvg%20onload=prompt()%3E

00:40:18 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task&extra=unclosed'%22%3E%3Csvg%20onload=prompt()%3E

00:40:18 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task&extra=unclosed'%22%3E%3Csvg%20onload=prompt()%3E

00:40:18 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task&extra=unclosed'%22%3E%3Csvg%20onload=prompt()%3E

00:40:18 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task&extra=unclosed'%22%3E%3Csvg%20onload=prompt()%3E

00:40:18 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task&extra=unclosed'%22%3E%3Csvg%20onload=prompt()%3E

00:40:18 Undefined property: router::$user in module/project/model.php on line 52 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task&extra=unclosed'%22%3E%3Csvg%20onload=prompt()%3E

00:40:18 Trying to get property of non-object in module/project/model.php on line 52 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task&extra=unclosed'%22%3E%3Csvg%20onload=prompt()%3E

00:40:18 Undefined property: router::$user in module/project/model.php on line 53 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task&extra=unclosed'%22%3E%3Csvg%20onload=prompt()%3E

00:40:18 Trying to get property of non-object in module/project/model.php on line 53 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task&extra=unclosed'%22%3E%3Csvg%20onload=prompt()%3E

00:40:18 Invalid argument supplied for foreach() in module/project/model.php on line 55 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=9&module=project&method=task&extra=unclosed'%22%3E%3Csvg%20onload=prompt()%3E
