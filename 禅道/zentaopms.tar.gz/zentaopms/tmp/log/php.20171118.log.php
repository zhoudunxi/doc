<?php
 die();
?>

16:38:58 Undefined index: branch in module/project/model.php on line 837 when visiting /www/index.php?m=project&f=create

16:45:55 Undefined index: branch in module/project/model.php on line 837 when visiting /www/index.php?m=project&f=manageproducts&projectID=24
