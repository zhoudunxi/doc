<?php
 die();
?>

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

12:06:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=45&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=46&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:03:01 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxgetdropmenu&t=html&objectid=47&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

14:09:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=36&module=bug&method=browse&extra=

17:42:45 Undefined offset: 1 in module/user/control.php on line 712 when visiting /www/index.php?m=user&f=login&referer=L3d3dy9pbmRleC5waHA=
