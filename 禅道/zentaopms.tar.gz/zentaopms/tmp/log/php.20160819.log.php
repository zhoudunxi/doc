<?php
 die();
?>

09:52:06 Undefined offset: 1 in module/user/control.php on line 712 when visiting /www/index.php?m=user&f=login&referer=L3d3dy9pbmRleC5waHA=

11:00:45 Trying to get property of non-object in module/story/model.php on line 896 when visiting /www/index.php?m=task&f=finish&taskID=234&onlybody=yes

11:00:45 Trying to get property of non-object in module/story/model.php on line 904 when visiting /www/index.php?m=task&f=finish&taskID=234&onlybody=yes

11:00:45 Trying to get property of non-object in module/story/model.php on line 906 when visiting /www/index.php?m=task&f=finish&taskID=234&onlybody=yes

11:00:45 Trying to get property of non-object in module/story/model.php on line 943 when visiting /www/index.php?m=task&f=finish&taskID=234&onlybody=yes

14:55:59 ERROR: the control file module/${@print(md5(233333))}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D&f=task&projectID=8&type=unclosed

14:58:01 ERROR: the control file module/${@print(md5(233333))}\/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D%5C&f=task&projectID=8&type=unclosed

14:59:41 ERROR: the control file module/print(md5(233333));die();/*/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=print%28md5%28233333%29%29%3Bdie%28%29%3B%2F*&f=task&projectID=8&type=unclosed

14:59:50 ERROR: the control file module/${7387324923+57832091}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7B7387324923%2b57832091%7D&f=task&projectID=8&type=unclosed

14:59:56 ERROR: the control file module/${new java.lang.string(new byte[]{97,98,99,100,101,102,120,97,120,102,101,100,99,98,97})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.lang.String(new%20byte%5B%5D%7B97,98,99,100,101,102,120,97,120,102,101,100,99,98,97%7D)%7D&f=task&projectID=8&type=unclosed

15:00:03 ERROR: the control file module/${new java.net.urlclassloader(new java.net.url[]{}).loadclass(new java.lang.string(new byte[]{111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115})).tostring(new byte[]{35,121,100,118,117,108,116,116,116,35})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.net.URLClassLoader(new%20java.net.URL%5B%5D%7B%7D).loadClass(new%20java.lang.String(new%20byte%5B%5D%7B111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115%7D)).toString(new%20byte%5B%5D%7B35,121,100,118,117,108,116,116,116,35%7D)%7D&f=task&projectID=8&type=unclosed

15:01:20 ERROR: the control file module/project'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=project'%22%3E%3Ciframe%20onload=alert()%3E&f=task&projectID=8&type=unclosed

15:01:30 ERROR: the control file module/project'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=project'%22%3E%3Cimg%20src=x%20onerror=prompt()%3E&f=task&projectID=8&type=unclosed

15:01:41 ERROR: the control file module/project'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=project'%22%3E%3Csvg%20onload=prompt()%3E&f=task&projectID=8&type=unclosed

15:01:51 ERROR: the control file module/projecti2027381i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=projecti2027381i&f=task&projectID=8&type=unclosed

15:01:52 ERROR: the control file module/projecti2027381i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=projecti2027381i&f=task&projectID=8&type=unclosed

15:01:55 ERROR: the control file module/projecti2027381i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=projecti2027381i&f=task&projectID=8&type=unclosed

15:01:57 ERROR: the control file module/projecti2027381i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=projecti2027381i&f=task&projectID=8&type=unclosed

15:02:03 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=task&projectID=8&type=unclosed

15:02:17 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=task&projectID=8&type=unclosed

15:02:35 ERROR: the control file module/projecti2027381i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=projecti2027381i&f=task&projectID=8&type=unclosed

15:03:26 ERROR: the control file module/${@print(md5(233333))}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D&f=view&id=1746

15:03:30 ERROR: the control file module/${@print(md5(233333))}\/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28233333%29%29%7D%5C&f=view&id=1746

15:03:35 ERROR: the control file module/print(md5(233333));die();/*/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=print%28md5%28233333%29%29%3Bdie%28%29%3B%2F*&f=view&id=1746

15:04:05 ERROR: the control file module/${7387324923+57832091}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7B7387324923%2b57832091%7D&f=view&id=1746

15:04:11 ERROR: the control file module/${new java.lang.string(new byte[]{97,98,99,100,101,102,120,97,120,102,101,100,99,98,97})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.lang.String(new%20byte%5B%5D%7B97,98,99,100,101,102,120,97,120,102,101,100,99,98,97%7D)%7D&f=view&id=1746

15:04:19 ERROR: the control file module/${new java.net.urlclassloader(new java.net.url[]{}).loadclass(new java.lang.string(new byte[]{111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115})).tostring(new byte[]{35,121,100,118,117,108,116,116,116,35})}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=$%7Bnew%20java.net.URLClassLoader(new%20java.net.URL%5B%5D%7B%7D).loadClass(new%20java.lang.String(new%20byte%5B%5D%7B111,114,103,46,97,112,97,99,104,101,46,99,111,109,109,111,110,115,46,105,111,46,73,79,85,116,105,108,115%7D)).toString(new%20byte%5B%5D%7B35,121,100,118,117,108,116,116,116,35%7D)%7D&f=view&id=1746

15:06:25 ERROR: the control file module/bug'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bug'%22%3E%3Ciframe%20onload=alert()%3E&f=view&id=1746

15:06:33 ERROR: the control file module/bug'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bug'%22%3E%3Cimg%20src=x%20onerror=prompt()%3E&f=view&id=1746

15:06:42 ERROR: the control file module/bug'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bug'%22%3E%3Csvg%20onload=prompt()%3E&f=view&id=1746

15:06:58 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=view&id=1746

15:07:10 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=view&id=1746
