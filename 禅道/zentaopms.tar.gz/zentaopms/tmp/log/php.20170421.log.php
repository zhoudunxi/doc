<?php
 die();
?>

11:01:25 Undefined offset: 1 in module/common/model.php on line 727 when visiting /www/index.php?m=bug&f=browse&productID=25&branch=&browseType=unclosed¶m=0&orderBy=&recTotal=172&recPerPage=20&pageID=2

11:02:09 ERROR: SQLSTATE[42S22]: Column not found: 1054 Unknown column '172' in 'order clause'The sql is: SELECT %s FROM %s wHeRe `openedby` = 'sunwei'  AND product  = '25' AND project IN ('16','14','12','11','10','8','7','6','4','3','2','1','0') AND deleted  = '0' oRdEr bY `172`,`id` asc   limit 0, 20  in lib/dao/dao.class.php on line 1074, last called by lib/dao/dao.class.php on line 526 through function sqlError.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bug&f=browse&productid=25&branch=0&browseType=openedByMe&param=0

11:02:18 ERROR: SQLSTATE[42S22]: Column not found: 1054 Unknown column '172' in 'order clause'The sql is: SELECT * FROM `zt_bug` wHeRe project IN ('16','14','12','11','10','8','7','6','4','3','2','1','0') AND product  = '25' AND status  != 'closed' AND deleted  = '0' oRdEr bY `172`,`id` asc   limit 0, 20  in lib/dao/dao.class.php on line 1074, last called by lib/dao/dao.class.php on line 526 through function sqlError.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bug&f=browse

11:24:16 ERROR: SQLSTATE[42S22]: Column not found: 1054 Unknown column '172' in 'order clause'The sql is: SELECT * FROM `zt_bug` wHeRe project IN ('16','14','12','11','10','8','7','6','4','3','2','1','0') AND product  = '25' AND status  != 'closed' AND deleted  = '0' oRdEr bY `172`,`id` asc   limit 0, 20  in lib/dao/dao.class.php on line 1074, last called by lib/dao/dao.class.php on line 526 through function sqlError.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bug&f=browse

11:24:31 ERROR: SQLSTATE[42S22]: Column not found: 1054 Unknown column '172' in 'order clause'The sql is: SELECT * FROM `zt_bug` wHeRe project IN ('16','14','12','11','10','8','7','6','4','3','2','1','0') AND product  = '25' AND status  != 'closed' AND deleted  = '0' oRdEr bY `172`,`id` asc   limit 0, 20  in lib/dao/dao.class.php on line 1074, last called by lib/dao/dao.class.php on line 526 through function sqlError.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bug&f=browse

11:24:49 ERROR: SQLSTATE[42S22]: Column not found: 1054 Unknown column '172' in 'order clause'The sql is: SELECT * FROM `zt_bug` wHeRe project IN ('16','14','12','11','10','8','7','6','4','3','2','1','0') AND product  = '25' AND status  != 'closed' AND deleted  = '0' oRdEr bY `172`,`id` asc   limit 0, 20  in lib/dao/dao.class.php on line 1074, last called by lib/dao/dao.class.php on line 526 through function sqlError.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bug&f=browse

11:25:11 ERROR: SQLSTATE[42S22]: Column not found: 1054 Unknown column '172' in 'order clause'The sql is: SELECT * FROM `zt_bug` wHeRe project IN ('16','14','12','11','10','8','7','6','4','3','2','1','0') AND product  = '25' AND status  != 'closed' AND deleted  = '0' oRdEr bY `172`,`id` asc   limit 0, 20  in lib/dao/dao.class.php on line 1074, last called by lib/dao/dao.class.php on line 526 through function sqlError.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bug&f=browse

11:28:24 ERROR: SQLSTATE[42S22]: Column not found: 1054 Unknown column '172' in 'order clause'The sql is: SELECT * FROM `zt_bug` wHeRe project IN ('16','14','12','11','10','8','7','6','4','3','2','1','0') AND product  = '25' AND status  != 'closed' AND deleted  = '0' oRdEr bY `172`,`id` asc   limit 0, 20  in lib/dao/dao.class.php on line 1074, last called by lib/dao/dao.class.php on line 526 through function sqlError.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bug&f=browse

11:28:46 ERROR: SQLSTATE[42S22]: Column not found: 1054 Unknown column '172' in 'order clause'The sql is: SELECT * FROM `zt_bug` wHeRe project IN ('16','14','12','11','10','8','7','6','4','3','2','1','0') AND product  = '25' AND status  != 'closed' AND deleted  = '0' oRdEr bY `172`,`id` asc   limit 0, 20  in lib/dao/dao.class.php on line 1074, last called by lib/dao/dao.class.php on line 526 through function sqlError.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bug&f=browse

13:01:31 Undefined offset: 1 in module/user/control.php on line 712 when visiting /www/index.php?m=user&f=login&referer=L3d3dy9pbmRleC5waHA=

13:41:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:41:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:42:00 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:45:50 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=25&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

13:48:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

15:39:00 Undefined offset: 1 in module/user/control.php on line 712 when visiting /www/index.php?m=user&f=login&referer=L3d3dy9pbmRleC5waHA=

17:12:43 Automatically populating $HTTP_RAW_POST_DATA is deprecated and will be removed in a future version. To avoid this warning set 'always_populate_raw_post_data' to '-1' in php.ini and use the php://input stream instead. in Unknown on line 0 when visiting /www/index.php

17:13:55 ERROR: the control file module/myi4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=myi4002091i&f=bug&t=html&type=assignedTo&orderBy=id_desc&recTotal=20&recPerPage=100&pageID=1

17:13:56 ERROR: the control file module/myi4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=myi4002091i&f=bug&t=html&type=assignedTo&orderBy=id_desc&recTotal=20&recPerPage=100&pageID=1

17:13:56 ERROR: the control file module/myi4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=myi4002091i&f=bug&t=html&type=assignedTo&orderBy=id_desc&recTotal=20&recPerPage=100&pageID=1

17:13:57 ERROR: the control file module/myi4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=myi4002091i&f=bug&t=html&type=assignedTo&orderBy=id_desc&recTotal=20&recPerPage=100&pageID=1

17:13:58 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=bug&t=html&type=assignedTo&orderBy=id_desc&recTotal=20&recPerPage=100&pageID=1

17:14:06 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=bug&t=html&type=assignedTo&orderBy=id_desc&recTotal=20&recPerPage=100&pageID=1

17:14:13 ERROR: the control file module/myi4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=myi4002091i&f=bug&t=html&type=assignedTo&orderBy=id_desc&recTotal=20&recPerPage=100&pageID=1

17:40:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

17:40:12 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:19 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

19:47:25 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=19&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

21:28:40 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=
