<?php
 die();
?>

09:46:57 Undefined offset: 1 in module/user/control.php on line 712 when visiting /www/index.php?m=user&f=login&referer=L3d3dy9pbmRleC5waHA=

10:34:29 ERROR: SQLSTATE[23000]: Integrity constraint violation: 1062 Duplicate entry 'caixiaodong-2' for key 'account'The sql is: INSERT INTO `zt_usergroup` SET `account` = 'caixiaodong',`group` = '2' in lib/dao/dao.class.php on line 1074, last called by lib/dao/dao.class.php on line 599 through function sqlError.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=user&f=edit&userID=31&from=company

10:48:56 Undefined variable: users in module/user/view/batchedit.html.php on line 39 when visiting /www/index.php?m=user&f=batchEdit&t=html&dept=0

10:48:56 Invalid argument supplied for foreach() in module/user/view/batchedit.html.php on line 39 when visiting /www/index.php?m=user&f=batchEdit&t=html&dept=0

20:56:14 Undefined offset: 1 in module/user/control.php on line 712 when visiting /www/index.php?m=user&f=login&referer=L3d3dy9pbmRleC5waHA=
