<?php
 die();
?>

16:06:53 Undefined property: router::$user in module/user/view/deny.html.php on line 15 when visiting /www/index.php?m=user&f=deny&module=release&method=create

16:06:53 Trying to get property of non-object in module/user/view/deny.html.php on line 15 when visiting /www/index.php?m=user&f=deny&module=release&method=create

16:06:58 Undefined property: router::$user in module/user/view/deny.html.php on line 15 when visiting /www/index.php?m=user&f=deny&module=release&method=create

16:06:58 Trying to get property of non-object in module/user/view/deny.html.php on line 15 when visiting /www/index.php?m=user&f=deny&module=release&method=create

16:20:35 ERROR: the control file module/useri4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=useri4002091i&f=deny&module=release&method=create

16:20:47 ERROR: the control file module/useri4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=useri4002091i&f=deny&module=release&method=create

16:20:53 ERROR: the control file module/useri4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=useri4002091i&f=deny&module=release&method=create

16:21:02 ERROR: the control file module/useri4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=useri4002091i&f=deny&module=release&method=create

16:21:51 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=view&t=html&id=2895

16:22:06 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=view&t=html&id=2895

16:22:16 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=deny&module=release&method=create

16:22:16 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=deny&module=release&method=create

16:22:29 ERROR: the control file module/bugi4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bugi4002091i&f=view&t=html&id=2895

16:22:32 Undefined property: router::$user in module/user/view/deny.html.php on line 15 when visiting /www/index.php?m=user&f=deny&module=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&method=create

16:22:32 Trying to get property of non-object in module/user/view/deny.html.php on line 15 when visiting /www/index.php?m=user&f=deny&module=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&method=create

16:22:32 Undefined property: language::$PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg== in module/user/view/deny.html.php on line 28 when visiting /www/index.php?m=user&f=deny&module=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&method=create

16:22:32 Invalid argument supplied for foreach() in module/user/view/deny.html.php on line 28 when visiting /www/index.php?m=user&f=deny&module=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&method=create

16:22:32 Undefined property: router::$user in module/user/view/deny.html.php on line 15 when visiting /www/index.php?m=user&f=deny&module=release&method=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==

16:22:32 Trying to get property of non-object in module/user/view/deny.html.php on line 15 when visiting /www/index.php?m=user&f=deny&module=release&method=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==

16:22:33 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=deny&module=release&method=create

16:22:34 Undefined property: router::$user in module/user/view/deny.html.php on line 15 when visiting /www/index.php?m=user&f=deny&module=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&method=create

16:22:34 Trying to get property of non-object in module/user/view/deny.html.php on line 15 when visiting /www/index.php?m=user&f=deny&module=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&method=create

16:22:34 Undefined property: language::$amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4 in module/user/view/deny.html.php on line 28 when visiting /www/index.php?m=user&f=deny&module=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&method=create

16:22:34 Invalid argument supplied for foreach() in module/user/view/deny.html.php on line 28 when visiting /www/index.php?m=user&f=deny&module=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&method=create

16:22:35 Undefined property: router::$user in module/user/view/deny.html.php on line 15 when visiting /www/index.php?m=user&f=deny&module=release&method=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4

16:22:35 Trying to get property of non-object in module/user/view/deny.html.php on line 15 when visiting /www/index.php?m=user&f=deny&module=release&method=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4

16:22:37 Undefined property: router::$user in module/user/view/deny.html.php on line 15 when visiting /www/index.php/'%22+onmouseover=alert()+d='%22/?m=user&f=deny&module=release&method=create

16:22:37 Trying to get property of non-object in module/user/view/deny.html.php on line 15 when visiting /www/index.php/'%22+onmouseover=alert()+d='%22/?m=user&f=deny&module=release&method=create

16:22:37 Undefined property: router::$user in module/user/view/deny.html.php on line 15 when visiting /www/index.php/%27%22%20onmouseover%3Dalert%28%29%20d%3D%27%22/?m=user&f=deny&module=release&method=create

16:22:37 Trying to get property of non-object in module/user/view/deny.html.php on line 15 when visiting /www/index.php/%27%22%20onmouseover%3Dalert%28%29%20d%3D%27%22/?m=user&f=deny&module=release&method=create

16:22:38 Undefined property: router::$user in module/user/view/deny.html.php on line 15 when visiting /www/index.php/%2527%2522%2520onmouseover%253Dalert%2528%2529%2520d%253D%2527%2522/?m=user&f=deny&module=release&method=create

16:22:38 Trying to get property of non-object in module/user/view/deny.html.php on line 15 when visiting /www/index.php/%2527%2522%2520onmouseover%253Dalert%2528%2529%2520d%253D%2527%2522/?m=user&f=deny&module=release&method=create

16:22:40 Undefined property: router::$user in module/user/view/deny.html.php on line 15 when visiting /www/index.php/'%22/%3E%3C/script%3E%3Cscript%3Ealert()%3C/script%3E/?m=user&f=deny&module=release&method=create

16:22:40 Trying to get property of non-object in module/user/view/deny.html.php on line 15 when visiting /www/index.php/'%22/%3E%3C/script%3E%3Cscript%3Ealert()%3C/script%3E/?m=user&f=deny&module=release&method=create

18:40:06 Undefined offset: 1 in module/user/control.php on line 712 when visiting /www/index.php?m=user&f=login&referer=L3d3dy9pbmRleC5waHA=

22:50:44 Undefined offset: 1 in module/user/control.php on line 712 when visiting /www/index.php?m=user&f=login&referer=L3d3dy9pbmRleC5waHA=
