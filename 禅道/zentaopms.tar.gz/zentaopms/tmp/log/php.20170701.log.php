<?php
 die();
?>

16:43:56 Undefined property: router::$user in module/user/view/deny.html.php on line 15 when visiting /www/index.php?m=user&f=deny&module=index&method=index

16:43:56 Trying to get property of non-object in module/user/view/deny.html.php on line 15 when visiting /www/index.php?m=user&f=deny&module=index&method=index
