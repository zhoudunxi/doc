<?php
 die();
?>

02:47:32 Automatically populating $HTTP_RAW_POST_DATA is deprecated and will be removed in a future version. To avoid this warning set 'always_populate_raw_post_data' to '-1' in php.ini and use the php://input stream instead. in Unknown on line 0 when visiting /www/index.php

02:50:53 ERROR: the control file module/myi4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=myi4002091i&f=bug&t=mhtml&type=resolvedBy

02:50:54 ERROR: the control file module/myi4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=myi4002091i&f=bug&t=mhtml&type=resolvedBy

02:50:56 ERROR: the control file module/myi4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=myi4002091i&f=bug&t=mhtml&type=resolvedBy

02:50:59 ERROR: the control file module/myi4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=myi4002091i&f=bug&t=mhtml&type=resolvedBy

02:50:59 ERROR: the control file module/myi4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=myi4002091i&f=bug&t=mhtml&type=resolvedBy

02:51:05 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=bug&t=mhtml&type=resolvedBy

02:51:16 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=bug&t=mhtml&type=resolvedBy

12:18:41 Undefined offset: 1 in module/user/control.php on line 712 when visiting /www/index.php?m=user&f=login&referer=L3d3dy9pbmRleC5waHA=

17:55:51 Undefined offset: 1 in module/user/control.php on line 712 when visiting /www/index.php?m=user&f=login&referer=L3d3dy9pbmRleC5waHA=

18:22:02 Undefined offset: 1 in module/user/control.php on line 712 when visiting /www/index.php?m=user&f=login&referer=L3d3dy9pbmRleC5waHA=

22:14:40 ERROR: SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') AND ( 1  AND `openedBy` = 'gujunchao'  )) AND `product` = 35  AND deleted  = '' at line 1The sql is: SELECT * FROM `zt_bug` wHeRe (( 1   AND `openedDate` between '2017-08-21'  ) AND ( 1  AND `openedBy` = 'gujunchao'  )) AND `product` = 35  AND deleted  = '0' oRdEr bY `openedDate` desc,`id` desc  in lib/dao/dao.class.php on line 1074, last called by lib/dao/dao.class.php on line 568 through function sqlError.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=bug&f=browse&productID=35&branch=0&browseType=bySearch&queryID=myQueryID

22:17:11 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/model.php on line 29 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/model.php on line 32 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/model.php on line 52 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/model.php on line 52 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/model.php on line 53 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/model.php on line 53 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Invalid argument supplied for foreach() in module/project/model.php on line 55 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 17 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 24 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Undefined property: router::$user in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed

22:17:11 Trying to get property of non-object in module/project/view/ajaxgetdropmenu.html.php on line 34 when visiting /www/index.php?m=project&f=ajaxGetDropMenu&t=html&objectID=16&module=project&method=task&extra=unclosed
