<?php
 die();
?>

11:36:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:45 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

11:36:55 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:25:53 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:04 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=27&module=bug&method=browse&extra=

14:30:20 Undefined property: stdClass::$files in module/bug/control.php on line 1344 when visiting /www/index.php?m=bug&f=export&productID=28&orderBy=id_desc

14:34:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:34:42 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=24&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:36:22 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:38:57 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=14&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:43:05 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=17&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:46:36 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=18&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

14:55:15 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=15&module=bug&method=browse&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:11:14 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:13:59 Undefined property: stdClass::$files in module/bug/control.php on line 1344 when visiting /www/index.php?m=bug&f=export&productID=18&orderBy=id_desc

15:13:59 Undefined property: stdClass::$files in module/bug/control.php on line 1344 when visiting /www/index.php?m=bug&f=export&productID=18&orderBy=id_desc

15:13:59 Undefined property: stdClass::$files in module/bug/control.php on line 1344 when visiting /www/index.php?m=bug&f=export&productID=18&orderBy=id_desc

15:13:59 Undefined property: stdClass::$files in module/bug/control.php on line 1344 when visiting /www/index.php?m=bug&f=export&productID=18&orderBy=id_desc

15:13:59 Undefined property: stdClass::$files in module/bug/control.php on line 1344 when visiting /www/index.php?m=bug&f=export&productID=18&orderBy=id_desc

15:13:59 Undefined property: stdClass::$files in module/bug/control.php on line 1344 when visiting /www/index.php?m=bug&f=export&productID=18&orderBy=id_desc

15:13:59 Undefined property: stdClass::$files in module/bug/control.php on line 1344 when visiting /www/index.php?m=bug&f=export&productID=18&orderBy=id_desc

15:18:24 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

15:18:24 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=28&module=product&method=index&extra=

17:51:36 Undefined offset: 1 in module/user/control.php on line 712 when visiting /www/index.php?m=user&f=login&referer=L3d3dy9pbmRleC5waHA=

18:06:49 Trying to get property of non-object in module/user/control.php on line 72 when visiting /www/index.php?m=user&f=todo&account=97

21:48:05 Undefined offset: 1 in module/user/control.php on line 712 when visiting /www/index.php?m=user&f=login&referer=L3d3dy9pbmRleC5waHA=
