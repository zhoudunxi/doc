<?php
 die();
?>

00:59:04 Automatically populating $HTTP_RAW_POST_DATA is deprecated and will be removed in a future version. To avoid this warning set 'always_populate_raw_post_data' to '-1' in php.ini and use the php://input stream instead. in Unknown on line 0 when visiting /www/index.php

01:12:31 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=browse&winzoom=1

01:12:57 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=browse&winzoom=1

10:05:13 Undefined index: branch in module/testcase/control.php on line 265 when visiting /www/index.php?m=testcase&f=create&productID=27&branch=0&moduleID=125

10:10:12 Undefined index: branch in module/testcase/control.php on line 265 when visiting /www/index.php?m=testcase&f=create&productID=27&branch=0&moduleID=125

10:19:50 Undefined index: branch in module/testcase/control.php on line 265 when visiting /www/index.php?m=testcase&f=create&productID=27&branch=0&moduleID=125

10:43:39 Undefined index: branch in module/testcase/control.php on line 265 when visiting /www/index.php?m=testcase&f=create&productID=27&branch=0&moduleID=125

11:03:09 Undefined index: branch in module/testcase/control.php on line 265 when visiting /www/index.php?m=testcase&f=create&productID=27&branch=0&moduleID=125

11:08:08 Undefined index: branch in module/testcase/control.php on line 265 when visiting /www/index.php?m=testcase&f=create&productID=27&branch=0&moduleID=125

11:14:35 Undefined index: branch in module/testcase/control.php on line 265 when visiting /www/index.php?m=testcase&f=create&productID=27&branch=0&moduleID=126

11:17:24 Undefined index: branch in module/testcase/control.php on line 265 when visiting /www/index.php?m=testcase&f=create&productID=27&branch=0&moduleID=126

11:21:41 Undefined index: branch in module/testcase/control.php on line 265 when visiting /www/index.php?m=testcase&f=create&productID=27&branch=0&moduleID=126

11:28:54 Undefined index: branch in module/testcase/control.php on line 265 when visiting /www/index.php?m=testcase&f=create&productID=27&branch=0&moduleID=126

11:31:08 Undefined index: branch in module/testcase/control.php on line 265 when visiting /www/index.php?m=testcase&f=create&productID=27&branch=0&moduleID=126

11:36:15 Undefined index: branch in module/testcase/control.php on line 265 when visiting /www/index.php?m=testcase&f=create&productID=27&branch=0&moduleID=127

11:39:00 Undefined index: branch in module/testcase/control.php on line 265 when visiting /www/index.php?m=testcase&f=create&productID=27&branch=0&moduleID=127

11:41:13 Undefined index: branch in module/testcase/control.php on line 265 when visiting /www/index.php?m=testcase&f=create&productID=27&branch=0&moduleID=127

11:55:15 Creating default object from empty value in module/dept/model.php on line 288 when visiting /www/index.php?m=dept&f=manageChild

11:56:05 Creating default object from empty value in module/dept/model.php on line 288 when visiting /www/index.php?m=dept&f=manageChild

04:28:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 117 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/model.php on line 120 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 15 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 16 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 23 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Undefined property: router::$user in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=

04:28:47 Trying to get property of non-object in module/product/view/ajaxgetdropmenu.html.php on line 33 when visiting /www/index.php?m=product&f=ajaxGetDropMenu&t=html&objectID=23&module=bug&method=browse&extra=
