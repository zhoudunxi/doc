<?php
 die();
?>

19:14:59 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=bug&type=resolvedBy

19:15:05 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=bug&type=resolvedBy

19:15:08 ERROR: the control file module/myi4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=myi4002091i&f=bug&type=resolvedBy

19:15:09 ERROR: the control file module/myi4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=myi4002091i&f=bug&type=resolvedBy

19:15:09 ERROR: the control file module/myi4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=myi4002091i&f=bug&type=resolvedBy

19:15:10 ERROR: the control file module/my'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=my'%22%3E%3Ciframe%20onload=alert()%3E&f=bug&type=resolvedBy

19:15:21 ERROR: the control file module/my'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=my'%22%3E%3Cimg%20src=x%20onerror=prompt()%3E&f=bug&type=resolvedBy

19:15:27 ERROR: the control file module/my'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=my'%22%3E%3Csvg%20onload=prompt()%3E&f=bug&type=resolvedBy

19:15:31 ERROR: the control file module/myi4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=myi4002091i&f=bug&type=resolvedBy

19:15:35 ERROR: the control file module/myi4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=myi4002091i&f=bug&type=resolvedBy
