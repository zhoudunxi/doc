<?php
 die();
?>

14:31:01 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=view&id=174

14:31:08 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=view&id=174

14:45:17 Trying to get property of non-object in module/story/model.php on line 896 when visiting /www/index.php?m=task&f=edit&taskID=161

14:45:17 Trying to get property of non-object in module/story/model.php on line 904 when visiting /www/index.php?m=task&f=edit&taskID=161

14:45:17 Trying to get property of non-object in module/story/model.php on line 906 when visiting /www/index.php?m=task&f=edit&taskID=161

14:45:17 Trying to get property of non-object in module/story/model.php on line 943 when visiting /www/index.php?m=task&f=edit&taskID=161

14:45:33 Trying to get property of non-object in module/story/model.php on line 896 when visiting /www/index.php?m=task&f=edit&taskID=161

14:45:33 Trying to get property of non-object in module/story/model.php on line 904 when visiting /www/index.php?m=task&f=edit&taskID=161

14:45:33 Trying to get property of non-object in module/story/model.php on line 906 when visiting /www/index.php?m=task&f=edit&taskID=161

14:45:33 Trying to get property of non-object in module/story/model.php on line 943 when visiting /www/index.php?m=task&f=edit&taskID=161

14:45:51 Trying to get property of non-object in module/story/model.php on line 896 when visiting /www/index.php?m=task&f=edit&taskID=161

14:45:51 Trying to get property of non-object in module/story/model.php on line 904 when visiting /www/index.php?m=task&f=edit&taskID=161

14:45:51 Trying to get property of non-object in module/story/model.php on line 906 when visiting /www/index.php?m=task&f=edit&taskID=161

14:45:51 Trying to get property of non-object in module/story/model.php on line 943 when visiting /www/index.php?m=task&f=edit&taskID=161

14:46:03 Trying to get property of non-object in module/story/model.php on line 896 when visiting /www/index.php?m=task&f=edit&taskID=161

14:46:03 Trying to get property of non-object in module/story/model.php on line 904 when visiting /www/index.php?m=task&f=edit&taskID=161

14:46:03 Trying to get property of non-object in module/story/model.php on line 906 when visiting /www/index.php?m=task&f=edit&taskID=161

14:46:03 Trying to get property of non-object in module/story/model.php on line 943 when visiting /www/index.php?m=task&f=edit&taskID=161

16:04:34 Undefined offset: 1 in module/user/control.php on line 712 when visiting /www/index.php?m=user&f=login&referer=L3d3dy9pbmRleC5waHA=

18:38:04 Trying to get property of non-object in module/story/model.php on line 896 when visiting /www/index.php?m=task&f=finish&taskID=176&onlybody=yes

18:38:04 Trying to get property of non-object in module/story/model.php on line 904 when visiting /www/index.php?m=task&f=finish&taskID=176&onlybody=yes

18:38:04 Trying to get property of non-object in module/story/model.php on line 906 when visiting /www/index.php?m=task&f=finish&taskID=176&onlybody=yes

18:38:04 Trying to get property of non-object in module/story/model.php on line 943 when visiting /www/index.php?m=task&f=finish&taskID=176&onlybody=yes
