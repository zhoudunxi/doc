<?php
 die();
?>

09:37:13 Undefined property: config::$plan in module/productplan/model.php on line 121 when visiting /www/index.php?m=productplan&f=create&productID=1&branch=0

09:37:13 Trying to get property of non-object in module/productplan/model.php on line 121 when visiting /www/index.php?m=productplan&f=create&productID=1&branch=0

09:37:13 Trying to get property of non-object in module/productplan/model.php on line 121 when visiting /www/index.php?m=productplan&f=create&productID=1&branch=0
