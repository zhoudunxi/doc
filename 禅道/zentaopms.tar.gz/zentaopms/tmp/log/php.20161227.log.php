<?php
 die();
?>

16:07:08 Undefined property: router::$user in module/user/view/deny.html.php on line 15 when visiting /www/index.php?m=user&f=deny&module=release&method=create

16:07:08 Trying to get property of non-object in module/user/view/deny.html.php on line 15 when visiting /www/index.php?m=user&f=deny&module=release&method=create

16:12:02 Undefined property: router::$user in module/user/view/deny.html.php on line 15 when visiting /www/index.php?m=user&f=deny&module=release&method=create

16:12:02 Trying to get property of non-object in module/user/view/deny.html.php on line 15 when visiting /www/index.php?m=user&f=deny&module=release&method=create

16:14:14 ERROR: the control file module/user'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=user'%22%3E%3Ciframe%20onload=alert()%3E&f=deny&module=release&method=create

16:16:16 ERROR: the control file module/project'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=project'%22%3E%3Ciframe%20onload=alert()%3E&f=task&project=11&type=all

16:25:27 ERROR: the control file module/user'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=user'%22%3E%3Cimg%20src=x%20onerror=prompt()%3E&f=deny&module=release&method=create

16:29:03 ERROR: the control file module/project'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=project'%22%3E%3Cimg%20src=x%20onerror=prompt()%3E&f=task&project=11&type=all

16:39:04 ERROR: the control file module/user'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=user'%22%3E%3Csvg%20onload=prompt()%3E&f=deny&module=release&method=create

16:41:41 ERROR: the control file module/project'">/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=project'%22%3E%3Csvg%20onload=prompt()%3E&f=task&project=11&type=all

16:50:25 ERROR: the control file module/useri4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=useri4002091i&f=deny&module=release&method=create

16:53:32 ERROR: the control file module/useri4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=useri4002091i&f=deny&module=release&method=create

16:54:15 ERROR: the control file module/projecti4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=projecti4002091i&f=task&project=11&type=all

16:57:30 ERROR: the control file module/useri4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=useri4002091i&f=deny&module=release&method=create

16:58:16 ERROR: the control file module/projecti4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=projecti4002091i&f=task&project=11&type=all

16:59:07 ERROR: the control file module/useri4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=useri4002091i&f=deny&module=release&method=create

16:59:21 ERROR: the control file module/projecti4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=projecti4002091i&f=task&project=11&type=all

17:01:22 Undefined property: router::$user in module/user/view/deny.html.php on line 15 when visiting /www/index.php?m=user&f=deny&module=release&method=create

17:01:22 Trying to get property of non-object in module/user/view/deny.html.php on line 15 when visiting /www/index.php?m=user&f=deny&module=release&method=create

17:05:41 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=deny&module=release&method=create

17:13:20 ERROR: the control file module/phnjcmlwdd5hbgvydcgxktwvc2nyaxb0pg==/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&f=task&project=11&type=all

17:14:21 Undefined property: router::$user in module/user/view/deny.html.php on line 15 when visiting /www/index.php?m=user&f=deny&module=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&method=create

17:14:21 Trying to get property of non-object in module/user/view/deny.html.php on line 15 when visiting /www/index.php?m=user&f=deny&module=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&method=create

17:14:21 Undefined property: language::$PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg== in module/user/view/deny.html.php on line 28 when visiting /www/index.php?m=user&f=deny&module=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&method=create

17:14:21 Invalid argument supplied for foreach() in module/user/view/deny.html.php on line 28 when visiting /www/index.php?m=user&f=deny&module=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==&method=create

17:18:22 Undefined property: router::$user in module/user/view/deny.html.php on line 15 when visiting /www/index.php?m=user&f=deny&module=release&method=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==

17:18:22 Trying to get property of non-object in module/user/view/deny.html.php on line 15 when visiting /www/index.php?m=user&f=deny&module=release&method=PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==

17:22:07 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=deny&module=release&method=create

17:34:13 Undefined property: router::$user in module/user/view/deny.html.php on line 15 when visiting /www/index.php?m=user&f=deny&module=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&method=create

17:34:13 Trying to get property of non-object in module/user/view/deny.html.php on line 15 when visiting /www/index.php?m=user&f=deny&module=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&method=create

17:34:13 Undefined property: language::$amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4 in module/user/view/deny.html.php on line 28 when visiting /www/index.php?m=user&f=deny&module=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&method=create

17:34:13 Invalid argument supplied for foreach() in module/user/view/deny.html.php on line 28 when visiting /www/index.php?m=user&f=deny&module=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&method=create

17:35:17 Undefined property: router::$user in module/user/view/deny.html.php on line 15 when visiting /www/index.php?m=user&f=deny&module=release&method=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4

17:35:17 Trying to get property of non-object in module/user/view/deny.html.php on line 15 when visiting /www/index.php?m=user&f=deny&module=release&method=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4

17:36:42 ERROR: the control file module/amf2yxnjcmlwddpwcm9tchqomtexktt4/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=amF2YXNjcmlwdDpwcm9tcHQoMTExKTt4&f=task&project=11&type=all

17:57:58 Undefined offset: 1 in module/bug/view/browse.html.php on line 70 when visiting /www/index.php?m=bug&f=browse&productID=15&winzoom=1

17:58:04 Undefined offset: 1 in module/bug/view/browse.html.php on line 70 when visiting /www/index.php?m=bug&f=browse&productID=15

18:04:27 Undefined offset: 1 in module/bug/view/browse.html.php on line 70 when visiting /www/index.php?m=bug&f=browse&productID=15&winzoom=1

18:04:32 Undefined offset: 1 in module/product/view/browse.html.php on line 61 when visiting /www/index.php?m=product&f=browse

18:09:36 ERROR: the control file module/useri4002091i/control.php not found. in framework/router.class.php on line 992, last called by framework/router.class.php on line 1100 through function setControlFile.
 in framework/router.class.php on line 1622 when visiting /www/index.php?m=useri4002091i&f=deny&module=release&method=create
