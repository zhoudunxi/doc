
var lang = new Array();

//attorn
lang['attorn_success'] = "转让成功！";

//catalog
lang["none"] = "无";
lang["save_success"] = "保存成功！";
lang["save_fail"] = "保存失败！";
lang["confirm_to_delete"] = "确认删除吗？";
lang["delete_success"] = "删除成功！";
lang["delete_fail"] = "删除失败！";

//item
lang["back_to_top"] = "回到顶部";


//page/edite
lang["params"] = "参数名";
lang["type"] = "类型";
lang["description"] = "说明";
lang["editormd_placeholder"] = "本编辑器支持Markdown编辑，左边编写，右边预览";
lang["json_fail"] = "json导入失败";
lang["filed"] = "键";
lang["none"] = "无";
lang["save_templ_title"] = "请为要保存的模板设置标题";
lang["saved_templ_msg1"] = "已经保存好模板“";
lang["saved_templ_msg2"] = "”。你以后新建或者编辑编辑页面时，点击“更多模板”按钮，便可以使用你保存的模板";
lang["save_time"] = "保存时间";
lang["templ_title"] = "模板标题";
lang["operation"] = "操作";
lang["use_this_template"] = "插入此模板";
lang["delete_this_template"] = "删除模板";
lang["no_templ_msg"] = "<p><br>你尚未保存过任何模板。<br>你可以在编辑页面时，在“保存”按钮右边点击，在下来菜单中选择“另存为模板”。<br>把页面内容保存为模板后，你下次新建或者编辑页面时便可以使用你之前保存的模板</p>";
lang["add_page_comments_msg"] = "请输入页面注释内容。可以填写你对页面的修改注释或者其它注释。添加后，在页面的历史版本处会显示每一个页面版本的注释，方便你查阅、追踪页面的修改";


lang["confirm_to_delete_member"] = "确认要删除该成员？";